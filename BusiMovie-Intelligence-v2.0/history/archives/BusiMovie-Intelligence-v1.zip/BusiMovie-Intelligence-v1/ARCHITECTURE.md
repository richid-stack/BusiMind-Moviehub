# Architecture

```text
                    BusiMovie Intelligence
                             |
        +--------------------+--------------------+
        |                    |                    |
     Eagle Eye             Hunter              Crawler
   "what is here?"      "how do I get it?"   "what is new?"
        |                    |                    |
        +--------------------+--------------------+
                             |
                     Verification Core
                             |
                    Media Identity Engine
                             |
              +--------------+--------------+
              |                             |
          PostgreSQL                       Redis
```

## Rules

1. `MediaType` is authoritative.
2. A bot result cannot redefine the request.
3. UNKNOWN is better than WRONG.
4. Episode number is never inferred from arrival order.
5. Latest-message fallbacks are forbidden.
6. Canonical media identity is distinct from release/quality.
7. Telegram transport is isolated behind a gateway.
8. External actions pass through Action Guard.
9. The LLM is a reasoner, not the source of truth.

## Eagle Eye

Normalizes Telegram surfaces into:

- text
- media
- reply context
- buttons
- semantic actions

The interaction graph stores observed state transitions.

## Hunter

A mission has a typed target and moves through:

`CREATED -> PLANNING -> EXPLORING -> CANDIDATE_FOUND -> VERIFYING -> EXECUTING -> OBSERVING -> SUCCESS/FAILED`

## Crawler

The crawler is event-oriented. A source event is converted into evidence, then canonical identity resolution, then verification, then indexing.

## Real integration boundary

`TelegramGateway` is the only package allowed to know the Telegram SDK. This prevents GramJS details from leaking into business logic.
