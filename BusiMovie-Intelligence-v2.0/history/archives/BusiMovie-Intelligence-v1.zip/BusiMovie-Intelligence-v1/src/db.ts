import pg from "pg";
import { readFile } from "node:fs/promises";
import path from "node:path";

export class Database {
  private pool?: pg.Pool;

  constructor(private readonly url = process.env.DATABASE_URL) {}

  connect() {
    if (!this.url) throw new Error("DATABASE_URL is not configured");
    this.pool = new pg.Pool({ connectionString: this.url });
    return this.pool;
  }

  async migrate() {
    if (!this.pool) this.connect();
    const sql = await readFile(path.resolve("sql/001_init.sql"), "utf8");
    await this.pool!.query(sql);
  }

  async close() {
    await this.pool?.end();
  }
}
