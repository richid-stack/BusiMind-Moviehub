import { TelegramButton, TelegramSurface } from "./domain.js";

export interface TelegramGateway {
  observe(chatId: string): Promise<TelegramSurface[]>;
  click(chatId: string, messageId: number, buttonId: string): Promise<TelegramSurface[]>;
  sendMessage(chatId: string, text: string): Promise<TelegramSurface[]>;
  forward(chatId: string, messageId: number, destinationChatId: string): Promise<TelegramSurface>;
}

export function buttonId(chatId: string, messageId: number, row: number, column: number): string {
  return `${chatId}:${messageId}:${row}:${column}`;
}

function classifyButton(text: string): TelegramButton["semanticKind"] {
  const t = text.toLowerCase().trim();
  if (/^next\b|next page|›|»/.test(t)) return "PAGINATION_NEXT";
  if (/^prev|previous|‹|«/.test(t)) return "PAGINATION_PREVIOUS";
  if (/season\s*\d+|^s\d+\b/.test(t)) return "SEASON_SELECT";
  if (/s\d+\s*e\d+|episode\s*\d+|^e\d+\b/.test(t)) return "EPISODE_SELECT";
  if (/2160p|1080p|720p|480p|4k/.test(t)) return "QUALITY_SELECT";
  if (/download|get file|watch|play/.test(t)) return "DOWNLOAD";
  if (/search/.test(t)) return "SEARCH";
  return "MEDIA_CANDIDATE";
}

export function normalizeSurface(input: Omit<TelegramSurface, "buttons"> & {
  buttons: Array<Omit<TelegramButton, "id" | "semanticKind">>
}): TelegramSurface {
  return {
    ...input,
    buttons: input.buttons.map(b => ({
      ...b,
      id: buttonId(input.chatId, input.messageId, b.row, b.column),
      semanticKind: classifyButton(b.text)
    }))
  };
}

/**
 * Clean-room replay gateway used by tests/demo.
 * It deliberately models a bot as surfaces and transitions, rather than
 * pretending every bot has a fixed UI.
 */
export class MockTelegramGateway implements TelegramGateway {
  private surfaces = new Map<string, TelegramSurface>();
  private nextMessage = 100;

  constructor() {
    this.seed();
  }

  private seed() {
    const s = normalizeSurface({
      chatId: "@Apple_moviebot",
      messageId: 100,
      sender: "@Apple_moviebot",
      text: "Search results for The Incredible Hulk",
      buttons: [
        { text: "The Incredible Hulk (2008)", type: "CALLBACK", row: 0, column: 0 },
        { text: "Hulk (2003)", type: "CALLBACK", row: 1, column: 0 }
      ],
      media: [],
      observedAt: new Date().toISOString()
    });
    this.surfaces.set(`${s.chatId}:${s.messageId}`, s);
  }

  async observe(chatId: string) {
    return [...this.surfaces.values()].filter(s => s.chatId === chatId);
  }

  async click(chatId: string, messageId: number, buttonIdValue: string) {
    const source = this.surfaces.get(`${chatId}:${messageId}`);
    if (!source) throw new Error("Surface not found");
    const button = source.buttons.find(b => b.id === buttonIdValue);
    if (!button) throw new Error("Button not found");

    const title = button.text;
    const messageIdNew = ++this.nextMessage;
    const result = normalizeSurface({
      chatId,
      messageId: messageIdNew,
      sender: chatId,
      text: `Selected ${title}`,
      buttons: [
        { text: "1080p", type: "CALLBACK", row: 0, column: 0 },
        { text: "720p", type: "CALLBACK", row: 0, column: 1 }
      ],
      media: [],
      replyToMessageId: messageId,
      observedAt: new Date().toISOString()
    });
    this.surfaces.set(`${chatId}:${messageIdNew}`, result);
    return [result];
  }

  async sendMessage(chatId: string, text: string) {
    const messageId = ++this.nextMessage;
    const result = normalizeSurface({
      chatId,
      messageId,
      sender: chatId,
      text,
      buttons: [],
      media: [],
      observedAt: new Date().toISOString()
    });
    this.surfaces.set(`${chatId}:${messageId}`, result);
    return [result];
  }

  async forward(chatId: string, messageId: number, destinationChatId: string) {
    const source = this.surfaces.get(`${chatId}:${messageId}`);
    if (!source) throw new Error("Source message not found");
    return {
      ...source,
      chatId: destinationChatId,
      messageId: ++this.nextMessage,
      sender: destinationChatId,
      replyToMessageId: undefined,
      observedAt: new Date().toISOString()
    };
  }
}

/**
 * Real GramJS adapter boundary. Authentication/session setup is intentionally
 * externalized; never commit TELEGRAM_SESSION.
 */
export class GramJsTelegramGateway implements TelegramGateway {
  async observe(_chatId: string): Promise<TelegramSurface[]> {
    throw new Error("GramJS adapter requires application-specific auth/session wiring. Use MockTelegramGateway for the v1 demo.");
  }
  async click(): Promise<TelegramSurface[]> {
    throw new Error("GramJS adapter action wiring not configured.");
  }
  async sendMessage(): Promise<TelegramSurface[]> {
    throw new Error("GramJS adapter action wiring not configured.");
  }
  async forward(): Promise<TelegramSurface> {
    throw new Error("GramJS adapter action wiring not configured.");
  }
}
