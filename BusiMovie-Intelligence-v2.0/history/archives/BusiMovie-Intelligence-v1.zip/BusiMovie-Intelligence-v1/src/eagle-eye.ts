import { InteractionEdge, TelegramSurface } from "./domain.js";

export class InteractionGraph {
  private surfaces = new Map<string, TelegramSurface>();
  private edges: InteractionEdge[] = [];

  recordSurface(surface: TelegramSurface) {
    const key = `${surface.chatId}:${surface.messageId}`;
    this.surfaces.set(key, surface);
  }

  recordTransition(from: TelegramSurface, actionId: string, to: TelegramSurface) {
    this.recordSurface(from);
    this.recordSurface(to);
    this.edges.push({
      fromSurface: `${from.chatId}:${from.messageId}`,
      actionId,
      toSurface: `${to.chatId}:${to.messageId}`,
      observedAt: new Date().toISOString()
    });
  }

  getSurface(chatId: string, messageId: number) {
    return this.surfaces.get(`${chatId}:${messageId}`);
  }

  snapshot() {
    return {
      surfaces: [...this.surfaces.values()],
      edges: [...this.edges]
    };
  }
}

export class EagleEye {
  constructor(private readonly graph = new InteractionGraph()) {}

  observe(surfaces: TelegramSurface[]) {
    for (const surface of surfaces) this.graph.recordSurface(surface);
    return surfaces.map(surface => ({
      surface,
      actionableButtons: surface.buttons.map(b => ({
        id: b.id,
        text: b.text,
        semanticKind: b.semanticKind
      }))
    }));
  }

  connect(from: TelegramSurface, actionId: string, to: TelegramSurface) {
    this.graph.recordTransition(from, actionId, to);
  }

  getGraph() {
    return this.graph.snapshot();
  }
}
