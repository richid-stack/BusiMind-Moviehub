import { AcquisitionJob, BotProfile, Candidate, MediaRequest, TelegramSurface } from "./domain.js";
import { EagleEye } from "./eagle-eye.js";
import { TelegramGateway } from "./telegram.js";
import { guardBot, guardButtonAction } from "./action-guard.js";
import { JobStateMachine, createJob } from "./jobs.js";
import { verifyCandidate } from "./identity.js";

export interface Reasoner {
  chooseAction(input: {
    request: MediaRequest;
    surface: TelegramSurface;
  }): Promise<{ buttonId: string } | { action: "WAIT" } | { action: "ABORT"; reason: string }>;
}

export class DeterministicReasoner implements Reasoner {
  async chooseAction({ request, surface }: {
    request: MediaRequest;
    surface: TelegramSurface;
  }) {
    const candidate = surface.buttons.find(b =>
      b.semanticKind === "MEDIA_CANDIDATE" &&
      b.text.toLowerCase().includes(request.title.toLowerCase().split(" ")[0])
    );

    if (candidate) return { buttonId: candidate.id };

    const quality = surface.buttons.find(b =>
      request.requestedQuality &&
      b.text.toLowerCase().includes(request.requestedQuality.toLowerCase())
    );

    if (quality) return { buttonId: quality.id };

    return { action: "WAIT" as const };
  }
}

export class Hunter {
  constructor(
    private readonly telegram: TelegramGateway,
    private readonly eagle: EagleEye,
    private readonly reasoner: Reasoner = new DeterministicReasoner()
  ) {}

  async inspectBot(request: MediaRequest, bot: BotProfile) {
    const guard = guardBot(request, bot);
    if (!guard.allowed) return { ok: false, reason: guard.reason };

    const surfaces = await this.telegram.observe(bot.username);
    return { ok: true, surfaces: this.eagle.observe(surfaces) };
  }

  async executeNavigation(
    job: AcquisitionJob,
    bot: BotProfile,
    initialSurface: TelegramSurface
  ) {
    const sm = new JobStateMachine(job);
    sm.transition("PLANNING");
    sm.transition("EXPLORING");

    let current = initialSurface;

    for (let step = 0; step < 8; step++) {
      const decision = await this.reasoner.chooseAction({
        request: job.request,
        surface: current
      });

      if ("action" in decision) {
        if (decision.action === "WAIT") return { job, status: "WAITING", surface: current };
        sm.transition("FAILED");
        job.failureReason = undefined;
        return { job, status: "ABORTED", reason: decision.reason };
      }

      const button = current.buttons.find(b => b.id === decision.buttonId);
      if (!button) {
        sm.transition("FAILED");
        return { job, status: "FAILED", reason: "BUTTON_NOT_FOUND" };
      }

      const actionGuard = guardButtonAction(job.request, button);
      if (!actionGuard.allowed) {
        sm.transition("FAILED");
        return { job, status: "FAILED", reason: actionGuard.reason };
      }

      const next = await this.telegram.click(current.chatId, current.messageId, button.id);
      if (!next[0]) {
        sm.transition("FAILED");
        return { job, status: "FAILED", reason: "NO_SURFACE_AFTER_ACTION" };
      }

      this.eagle.connect(current, button.id, next[0]);
      current = next[0];

      if (button.semanticKind === "MEDIA_CANDIDATE") {
        sm.transition("CANDIDATE_FOUND");
        return { job, status: "CANDIDATE_FOUND", surface: current };
      }
    }

    sm.transition("FAILED");
    return { job, status: "FAILED", reason: "MAX_NAVIGATION_STEPS" };
  }

  createMission(request: MediaRequest) {
    return createJob(request);
  }

  verify(job: AcquisitionJob, candidate: Candidate) {
    const result = verifyCandidate(job.request, candidate);
    if (!result.ok) return result;
    job.confidence = result.confidence;
    return result;
  }
}
