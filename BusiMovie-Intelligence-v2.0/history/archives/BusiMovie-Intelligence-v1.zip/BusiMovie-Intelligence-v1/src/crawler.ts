import { CrawlerTarget, Evidence } from "./domain.js";
import { evidenceFromCaption } from "./identity.js";

export interface CrawlerEvent {
  target: CrawlerTarget;
  chatId: string;
  messageId: number;
  caption?: string;
  text?: string;
}

export interface CrawlerSink {
  ingestEvidence(event: CrawlerEvent, evidence: Evidence[]): Promise<void>;
}

export class CrawlerEngine {
  constructor(private readonly sink: CrawlerSink) {}

  async process(event: CrawlerEvent) {
    if (!event.target.enabled) return { status: "IGNORED", reason: "TARGET_DISABLED" };

    const sourceText = event.caption ?? event.text ?? "";
    const evidence = evidenceFromCaption(sourceText, event.chatId);

    await this.sink.ingestEvidence(event, evidence);

    return {
      status: "DISCOVERED",
      evidenceCount: evidence.length
    };
  }
}
