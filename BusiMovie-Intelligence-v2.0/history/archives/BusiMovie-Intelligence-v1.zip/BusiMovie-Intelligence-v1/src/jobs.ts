import { AcquisitionJob, AcquisitionStatus, MediaRequest, FailureReason } from "./domain.js";

const transitions: Record<AcquisitionStatus, AcquisitionStatus[]> = {
  CREATED: ["PLANNING", "FAILED"],
  PLANNING: ["EXPLORING", "FAILED"],
  EXPLORING: ["CANDIDATE_FOUND", "FAILED"],
  CANDIDATE_FOUND: ["VERIFYING", "FAILED"],
  VERIFYING: ["FORWARDING", "INDEXING", "FAILED"],
  FORWARDING: ["INDEXING", "FAILED"],
  INDEXING: ["VERIFIED", "FAILED"],
  VERIFIED: ["SUCCESS"],
  SUCCESS: [],
  FAILED: []
};

export class JobStateMachine {
  constructor(public readonly job: AcquisitionJob) {}

  transition(next: AcquisitionStatus, failureReason?: FailureReason) {
    if (!transitions[this.job.status].includes(next)) {
      throw new Error(`Invalid job transition ${this.job.status} -> ${next}`);
    }
    this.job.status = next;
    this.job.updatedAt = new Date().toISOString();
    if (failureReason) this.job.failureReason = failureReason;
  }
}

export function createJob(request: MediaRequest, id = crypto.randomUUID()): AcquisitionJob {
  const now = new Date().toISOString();
  return {
    id,
    request,
    status: "CREATED",
    createdAt: now,
    updatedAt: now
  };
}
