import { MediaRequest, TelegramButton } from "./domain.js";

export type GuardDecision =
  | { allowed: true }
  | { allowed: false; reason: string };

export function guardButtonAction(
  request: MediaRequest,
  button: TelegramButton
): GuardDecision {
  if (request.mediaType === "MOVIE" && button.semanticKind === "SEASON_SELECT") {
    return { allowed: false, reason: "MOVIE_CANNOT_ENTER_SEASON_NAVIGATION" };
  }

  if (request.mediaType === "MOVIE" && button.semanticKind === "EPISODE_SELECT") {
    return { allowed: false, reason: "MOVIE_CANNOT_ENTER_EPISODE_NAVIGATION" };
  }

  return { allowed: true };
}

export function guardBot(
  request: MediaRequest,
  bot: { mediaPolicy: "MOVIE" | "SERIES" | "MIXED" }
): GuardDecision {
  if (bot.mediaPolicy !== "MIXED" && bot.mediaPolicy !== request.mediaType) {
    return { allowed: false, reason: "BOT_MEDIA_POLICY_MISMATCH" };
  }
  return { allowed: true };
}
