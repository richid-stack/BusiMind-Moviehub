import { BotProfile, MediaType } from "./domain.js";

export const DEFAULT_BOTS: BotProfile[] = [
  {
    username: "@Apple_moviebot",
    mediaPolicy: "MOVIE",
    capabilities: ["MOVIE_SEARCH", "QUALITY_SELECTION"],
    priority: 1,
    reliability: 0.95,
    enabled: true
  },
  {
    username: "@iPapkornDeltaBot",
    mediaPolicy: "MOVIE",
    capabilities: ["MOVIE_SEARCH", "QUALITY_SELECTION"],
    priority: 2,
    reliability: 0.80,
    enabled: true
  },
  {
    username: "@iPapkornEzPzBot",
    mediaPolicy: "MOVIE",
    capabilities: ["MOVIE_SEARCH", "QUALITY_SELECTION"],
    priority: 3,
    reliability: 0.70,
    enabled: true
  },
  {
    username: "@quinsonnbot",
    mediaPolicy: "SERIES",
    capabilities: ["SERIES_SEARCH", "SEASON_NAVIGATION", "EPISODE_NAVIGATION"],
    priority: 1,
    reliability: 0.85,
    enabled: true
  }
];

export function eligibleBots(mediaType: MediaType, bots = DEFAULT_BOTS) {
  return bots
    .filter(b => b.enabled && (b.mediaPolicy === mediaType || b.mediaPolicy === "MIXED"))
    .sort((a, b) => a.priority - b.priority);
}
