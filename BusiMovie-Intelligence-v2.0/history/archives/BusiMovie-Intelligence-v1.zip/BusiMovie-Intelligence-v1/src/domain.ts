import { z } from "zod";

export const MediaTypeSchema = z.enum(["MOVIE", "SERIES"]);
export type MediaType = z.infer<typeof MediaTypeSchema>;

export const MediaRequestSchema = z.object({
  mediaType: MediaTypeSchema,
  title: z.string().min(1),
  canonicalId: z.string().optional(),
  originalTitle: z.string().optional(),
  year: z.number().int().positive().optional(),
  seasonNumber: z.number().int().positive().optional(),
  episodeNumber: z.number().int().positive().optional(),
  requestedQuality: z.string().optional()
}).superRefine((v, ctx) => {
  if (v.mediaType === "MOVIE" && (v.seasonNumber || v.episodeNumber)) {
    ctx.addIssue({ code: "custom", message: "MOVIE cannot contain season/episode identity" });
  }
});

export type MediaRequest = z.infer<typeof MediaRequestSchema>;

export type AcquisitionStatus =
  | "CREATED" | "PLANNING" | "EXPLORING" | "CANDIDATE_FOUND"
  | "VERIFYING" | "FORWARDING" | "INDEXING" | "VERIFIED"
  | "SUCCESS" | "FAILED";

export type FailureReason =
  | "MEDIA_TYPE_MISMATCH"
  | "CANONICAL_ID_MISMATCH"
  | "YEAR_MISMATCH"
  | "SEASON_MISMATCH"
  | "EPISODE_MISMATCH"
  | "AMBIGUOUS_METADATA"
  | "UNVERIFIED_TELEGRAM_MESSAGE"
  | "STALE_MESSAGE"
  | "WRONG_VAULT"
  | "BOT_TIMEOUT"
  | "BOT_NO_RESULT"
  | "FORWARD_FAILED"
  | "INDEX_FAILED"
  | "DUPLICATE_ASSET";

export interface CanonicalMediaIdentity {
  mediaType: MediaType;
  canonicalId: string;
  title: string;
  originalTitle?: string;
  year?: number;
  tmdbId?: string;
  imdbId?: string;
}

export interface Candidate {
  identity: CanonicalMediaIdentity;
  seasonNumber?: number;
  episodeNumber?: number;
  evidence: Evidence[];
  confidence: number;
}

export interface Evidence {
  kind: string;
  value: string;
  source: string;
  confidence?: number;
}

export interface AcquisitionJob {
  id: string;
  request: MediaRequest;
  status: AcquisitionStatus;
  sourceBot?: string;
  sourceMessageId?: number;
  destinationMessageId?: number;
  confidence?: number;
  failureReason?: FailureReason;
  createdAt: string;
  updatedAt: string;
}

export type ButtonKind =
  | "MEDIA_CANDIDATE"
  | "SEASON_SELECT"
  | "EPISODE_SELECT"
  | "QUALITY_SELECT"
  | "DOWNLOAD"
  | "PAGINATION_NEXT"
  | "PAGINATION_PREVIOUS"
  | "SEARCH"
  | "UNKNOWN";

export interface TelegramButton {
  id: string;
  text: string;
  type: "CALLBACK" | "URL" | "COMMAND" | "INLINE" | "UNKNOWN";
  callbackData?: string;
  url?: string;
  row: number;
  column: number;
  semanticKind?: ButtonKind;
}

export interface TelegramMedia {
  kind: "VIDEO" | "DOCUMENT" | "AUDIO" | "PHOTO" | "OTHER";
  fileId?: string;
  fileName?: string;
  mimeType?: string;
}

export interface TelegramSurface {
  chatId: string;
  messageId: number;
  sender: string;
  text?: string;
  caption?: string;
  replyToMessageId?: number;
  buttons: TelegramButton[];
  media: TelegramMedia[];
  observedAt: string;
}

export interface InteractionEdge {
  fromSurface: string;
  actionId: string;
  toSurface: string;
  observedAt: string;
}

export interface BotProfile {
  username: string;
  mediaPolicy: MediaType | "MIXED";
  capabilities: string[];
  priority: number;
  reliability: number;
  enabled: boolean;
}

export interface CrawlerTarget {
  id: string;
  source: string;
  mediaPolicy: MediaType | "MIXED";
  destinationVault: "MOVIE_VAULT" | "SERIES_VAULT" | "CLASSIFIER";
  enabled: boolean;
  priority: number;
}
