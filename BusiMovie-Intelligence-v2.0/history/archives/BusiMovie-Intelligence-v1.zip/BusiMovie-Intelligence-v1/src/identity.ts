import { Candidate, Evidence, MediaRequest, MediaType } from "./domain.js";

export function normalizeTitle(value: string): string {
  return value
    .toLowerCase()
    .replace(/[._\-:()[\],]/g, " ")
    .replace(/\b(2160p|1080p|720p|480p|bluray|web[- ]?dl|webrip|x264|x265|hevc)\b/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function titleSimilarity(a: string, b: string): number {
  const aa = new Set(normalizeTitle(a).split(" ").filter(Boolean));
  const bb = new Set(normalizeTitle(b).split(" ").filter(Boolean));
  if (!aa.size || !bb.size) return 0;
  const intersection = [...aa].filter(x => bb.has(x)).length;
  return intersection / Math.max(aa.size, bb.size);
}

export function verifyCandidate(request: MediaRequest, candidate: Candidate):
  { ok: true; confidence: number } |
  { ok: false; reason: string } {

  if (candidate.identity.mediaType !== request.mediaType) {
    return { ok: false, reason: "MEDIA_TYPE_MISMATCH" };
  }

  if (request.canonicalId && candidate.identity.canonicalId !== request.canonicalId) {
    return { ok: false, reason: "CANONICAL_ID_MISMATCH" };
  }

  if (request.year && candidate.identity.year && request.year !== candidate.identity.year) {
    return { ok: false, reason: "YEAR_MISMATCH" };
  }

  if (request.mediaType === "MOVIE" &&
      (candidate.seasonNumber !== undefined || candidate.episodeNumber !== undefined)) {
    return { ok: false, reason: "MEDIA_TYPE_MISMATCH" };
  }

  if (request.seasonNumber !== undefined && candidate.seasonNumber !== request.seasonNumber) {
    return { ok: false, reason: "SEASON_MISMATCH" };
  }

  if (request.episodeNumber !== undefined && candidate.episodeNumber !== request.episodeNumber) {
    return { ok: false, reason: "EPISODE_MISMATCH" };
  }

  const similarity = titleSimilarity(request.title, candidate.identity.title);
  const confidence = Math.max(candidate.confidence, similarity);

  if (confidence < 0.72) {
    return { ok: false, reason: "AMBIGUOUS_METADATA" };
  }

  return { ok: true, confidence };
}

export function evidenceFromCaption(caption: string, source: string): Evidence[] {
  const evidence: Evidence[] = [];
  const year = caption.match(/\b(19|20)\d{2}\b/)?.[0];
  const quality = caption.match(/\b(2160p|1080p|720p|480p)\b/i)?.[0];

  if (year) evidence.push({ kind: "YEAR", value: year, source, confidence: 0.7 });
  if (quality) evidence.push({ kind: "QUALITY", value: quality, source, confidence: 0.9 });

  const episode = caption.match(/\bS(\d{1,2})E(\d{1,3})\b/i);
  if (episode) {
    evidence.push({ kind: "SEASON", value: episode[1], source, confidence: 0.9 });
    evidence.push({ kind: "EPISODE", value: episode[2], source, confidence: 0.9 });
  }

  return evidence;
}
