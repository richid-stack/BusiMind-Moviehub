import "dotenv/config";
import { DEFAULT_BOTS, eligibleBots } from "./bots.js";
import { EagleEye } from "./eagle-eye.js";
import { Hunter } from "./hunter.js";
import { MockTelegramGateway } from "./telegram.js";
import { MediaRequestSchema } from "./domain.js";

async function demo() {
  const request = MediaRequestSchema.parse({
    mediaType: "MOVIE",
    title: "The Incredible Hulk",
    year: 2008,
    requestedQuality: "1080p"
  });

  const telegram = new MockTelegramGateway();
  const eagle = new EagleEye();
  const hunter = new Hunter(telegram, eagle);

  const bots = eligibleBots(request.mediaType);
  console.log("Eligible movie bots:", bots.map(b => b.username));

  const primary = bots[0];
  const inspected = await hunter.inspectBot(request, primary);
  console.log("Eagle Eye inspection:", JSON.stringify(inspected, null, 2));

  if (!inspected.ok) return;

  const surface = inspected.surfaces[0]?.surface;
  if (!surface) throw new Error("No surface");

  const job = hunter.createMission(request);
  const result = await hunter.executeNavigation(job, primary, surface);

  console.log("Hunter result:", JSON.stringify(result, null, 2));
  console.log("Interaction graph:", JSON.stringify(eagle.getGraph(), null, 2));
}

async function main() {
  if (process.argv[2] === "demo") {
    await demo();
    return;
  }

  console.log(`
BusiMovie Intelligence v1

Commands:
  npm run demo
  npm test
  npm run typecheck

Use DATABASE_URL + docker-compose for PostgreSQL.
Use Telegram credentials only with the real GramJS adapter.
`);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
