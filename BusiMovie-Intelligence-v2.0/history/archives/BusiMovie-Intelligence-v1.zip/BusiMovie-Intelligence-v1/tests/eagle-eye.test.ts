import { describe, expect, it } from "vitest";
import { EagleEye } from "../src/eagle-eye.js";
import { normalizeSurface, MockTelegramGateway } from "../src/telegram.js";

describe("Eagle Eye", () => {
  it("sees and semantically classifies buttons", async () => {
    const surface = normalizeSurface({
      chatId: "@quinsonnbot",
      messageId: 1,
      sender: "@quinsonnbot",
      text: "Choose season",
      buttons: [
        { text: "Season 1", type: "CALLBACK", row: 0, column: 0 },
        { text: "Next Page", type: "CALLBACK", row: 0, column: 1 }
      ],
      media: [],
      observedAt: new Date().toISOString()
    });

    const eye = new EagleEye();
    const result = eye.observe([surface]);

    expect(result[0].actionableButtons[0].semanticKind).toBe("SEASON_SELECT");
    expect(result[0].actionableButtons[1].semanticKind).toBe("PAGINATION_NEXT");
  });

  it("records an interaction graph", async () => {
    const tg = new MockTelegramGateway();
    const surface = (await tg.observe("@Apple_moviebot"))[0];
    const eye = new EagleEye();
    eye.observe([surface]);
    const next = await tg.click("@Apple_moviebot", surface.messageId, surface.buttons[0].id);
    eye.connect(surface, surface.buttons[0].id, next[0]);

    expect(eye.getGraph().edges).toHaveLength(1);
  });
});
