import { describe, expect, it } from "vitest";
import { verifyCandidate, titleSimilarity } from "../src/identity.js";
import { MediaRequest } from "../src/domain.js";

describe("media identity", () => {
  it("rejects movie -> series crossover", () => {
    const request: MediaRequest = {
      mediaType: "MOVIE",
      title: "The Incredible Hulk",
      year: 2008
    };

    const result = verifyCandidate(request, {
      identity: {
        mediaType: "SERIES",
        canonicalId: "tmdb:wrong",
        title: "The Incredible Hulk",
        year: 2008
      },
      confidence: 1,
      evidence: []
    });

    expect(result).toEqual({ ok: false, reason: "MEDIA_TYPE_MISMATCH" });
  });

  it("separates Hulk 2003 from Incredible Hulk 2008", () => {
    expect(titleSimilarity("Hulk", "The Incredible Hulk")).toBeGreaterThan(0);
    const request: MediaRequest = {
      mediaType: "MOVIE",
      title: "The Incredible Hulk",
      year: 2008
    };

    const result = verifyCandidate(request, {
      identity: {
        mediaType: "MOVIE",
        canonicalId: "tmdb:hulk-2003",
        title: "Hulk",
        year: 2003
      },
      confidence: 1,
      evidence: []
    });

    expect(result).toEqual({ ok: false, reason: "YEAR_MISMATCH" });
  });

  it("rejects wrong episode", () => {
    const request: MediaRequest = {
      mediaType: "SERIES",
      title: "Example Series",
      canonicalId: "tmdb:series",
      seasonNumber: 1,
      episodeNumber: 5
    };

    const result = verifyCandidate(request, {
      identity: {
        mediaType: "SERIES",
        canonicalId: "tmdb:series",
        title: "Example Series"
      },
      seasonNumber: 1,
      episodeNumber: 6,
      confidence: 1,
      evidence: []
    });

    expect(result).toEqual({ ok: false, reason: "EPISODE_MISMATCH" });
  });
});
