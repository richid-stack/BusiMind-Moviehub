import { describe, expect, it } from "vitest";
import { CrawlerEngine } from "../src/crawler.js";

describe("Crawler", () => {
  it("extracts structured evidence from a discovered asset", async () => {
    const seen: any[] = [];
    const crawler = new CrawlerEngine({
      async ingestEvidence(event, evidence) {
        seen.push({ event, evidence });
      }
    });

    const result = await crawler.process({
      target: {
        id: "movie-source",
        source: "@movies",
        mediaPolicy: "MOVIE",
        destinationVault: "MOVIE_VAULT",
        enabled: true,
        priority: 1
      },
      chatId: "@movies",
      messageId: 55,
      caption: "The.Incredible.Hulk.2008.1080p.WEB-DL"
    });

    expect(result.status).toBe("DISCOVERED");
    expect(seen[0].evidence.some((x: any) => x.kind === "YEAR")).toBe(true);
    expect(seen[0].evidence.some((x: any) => x.kind === "QUALITY")).toBe(true);
  });
});
