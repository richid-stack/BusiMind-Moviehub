import { describe, expect, it } from "vitest";
import { EagleEye } from "../src/eagle-eye.js";
import { Hunter } from "../src/hunter.js";
import { MockTelegramGateway } from "../src/telegram.js";

describe("Hunter", () => {
  it("navigates a mock movie bot without entering a series route", async () => {
    const tg = new MockTelegramGateway();
    const eye = new EagleEye();
    const hunter = new Hunter(tg, eye);

    const request = {
      mediaType: "MOVIE" as const,
      title: "The Incredible Hulk",
      year: 2008
    };

    const inspection = await hunter.inspectBot(request, {
      username: "@Apple_moviebot",
      mediaPolicy: "MOVIE",
      capabilities: ["MOVIE_SEARCH"],
      priority: 1,
      reliability: 1,
      enabled: true
    });

    expect(inspection.ok).toBe(true);

    if (!inspection.ok) return;
    const result = await hunter.executeNavigation(
      hunter.createMission(request),
      {
        username: "@Apple_moviebot",
        mediaPolicy: "MOVIE",
        capabilities: ["MOVIE_SEARCH"],
        priority: 1,
        reliability: 1,
        enabled: true
      },
      inspection.surfaces[0].surface
    );

    expect(result.status).toBe("CANDIDATE_FOUND");
  });
});
