import { describe, expect, it } from "vitest";
import { guardButtonAction, guardBot } from "../src/action-guard.js";

describe("action guard", () => {
  it("prevents movie from entering season navigation", () => {
    const result = guardButtonAction(
      { mediaType: "MOVIE", title: "The Incredible Hulk" },
      {
        id: "1",
        text: "Season 1",
        type: "CALLBACK",
        row: 0,
        column: 0,
        semanticKind: "SEASON_SELECT"
      }
    );

    expect(result.allowed).toBe(false);
  });

  it("prevents movie from using series-only bot", () => {
    const result = guardBot(
      { mediaType: "MOVIE", title: "The Incredible Hulk" },
      { mediaPolicy: "SERIES" }
    );

    expect(result.allowed).toBe(false);
  });
});
