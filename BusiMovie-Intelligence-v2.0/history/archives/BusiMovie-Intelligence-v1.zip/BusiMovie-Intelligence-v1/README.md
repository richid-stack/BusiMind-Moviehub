# BusiMovie Intelligence v1

A clean-room v1 architecture for an intelligent media acquisition platform.

## What is included

- Canonical Movie / Series / Season / Episode / Release / Telegram Asset domain model
- Strict media-type gates
- Evidence-based identity resolution
- Acquisition job state machine
- Movie bot priority chain:
  1. `@Apple_moviebot`
  2. `@iPapkornDeltaBot`
  3. `@iPapkornEzPzBot`
- Series route through `@quinsonnbot`
- Eagle Eye Telegram surface normalization
- Button semantic classification
- Interaction graph
- Hunter mission planner/executor
- Action Guard
- Replayable mock Telegram gateway
- Crawler engine
- PostgreSQL schema
- Redis boundary
- GramJS gateway boundary
- Structured logging
- Vitest regression tests
- Docker Compose for PostgreSQL + Redis

## Important safety/design property

The AI/agent layer does not own identity or safety decisions.

Deterministic code owns:

- media type
- canonical identity validation
- job state transitions
- action authorization
- vault routing
- duplicate checks

An intelligent model can later be plugged into the `Reasoner` interface for ambiguous navigation and planning.

## Run

```bash
cp .env.example .env
npm install
npm run typecheck
npm test
npm run demo
```

The demo uses a mock Telegram environment and does not require Telegram credentials.

## Real Telegram

Fill the Telegram variables in `.env` and use the `GramJsTelegramGateway`. Do not commit session strings or API credentials.

## Architecture

See `ARCHITECTURE.md`.
