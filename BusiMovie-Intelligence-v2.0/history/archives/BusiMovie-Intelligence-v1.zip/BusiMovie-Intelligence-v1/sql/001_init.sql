CREATE TABLE IF NOT EXISTS media_entities (
  id TEXT PRIMARY KEY,
  media_type TEXT NOT NULL CHECK (media_type IN ('MOVIE','SERIES')),
  canonical_id TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  original_title TEXT,
  year INTEGER,
  tmdb_id TEXT,
  imdb_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS episodes (
  id TEXT PRIMARY KEY,
  series_id TEXT NOT NULL REFERENCES media_entities(id),
  season_number INTEGER NOT NULL,
  episode_number INTEGER NOT NULL,
  title TEXT,
  UNIQUE(series_id, season_number, episode_number)
);

CREATE TABLE IF NOT EXISTS releases (
  id TEXT PRIMARY KEY,
  media_entity_id TEXT,
  episode_id TEXT REFERENCES episodes(id),
  quality TEXT,
  codec TEXT,
  audio TEXT,
  source TEXT,
  UNIQUE(media_entity_id, episode_id, quality, codec, audio, source)
);

CREATE TABLE IF NOT EXISTS telegram_assets (
  id TEXT PRIMARY KEY,
  release_id TEXT REFERENCES releases(id),
  chat_id TEXT NOT NULL,
  message_id BIGINT NOT NULL,
  caption TEXT,
  source_job_id TEXT,
  verification_status TEXT NOT NULL DEFAULT 'UNVERIFIED',
  UNIQUE(chat_id, message_id)
);

CREATE TABLE IF NOT EXISTS acquisition_jobs (
  id TEXT PRIMARY KEY,
  media_type TEXT NOT NULL CHECK (media_type IN ('MOVIE','SERIES')),
  canonical_media_id TEXT,
  title TEXT NOT NULL,
  year INTEGER,
  season_number INTEGER,
  episode_number INTEGER,
  status TEXT NOT NULL,
  source_bot TEXT,
  source_message_id BIGINT,
  destination_message_id BIGINT,
  confidence NUMERIC,
  failure_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS acquisition_events (
  id TEXT PRIMARY KEY,
  job_id TEXT NOT NULL REFERENCES acquisition_jobs(id),
  stage TEXT NOT NULL,
  event_type TEXT NOT NULL,
  status TEXT NOT NULL,
  source TEXT,
  source_message_id BIGINT,
  destination_message_id BIGINT,
  metadata JSONB,
  error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS crawler_targets (
  id TEXT PRIMARY KEY,
  source TEXT NOT NULL UNIQUE,
  media_policy TEXT NOT NULL CHECK (media_policy IN ('MOVIE','SERIES','MIXED')),
  destination_vault TEXT NOT NULL CHECK (destination_vault IN ('MOVIE_VAULT','SERIES_VAULT','CLASSIFIER')),
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  priority INTEGER NOT NULL DEFAULT 100
);

CREATE TABLE IF NOT EXISTS bot_profiles (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  media_policy TEXT NOT NULL CHECK (media_policy IN ('MOVIE','SERIES','MIXED')),
  capabilities JSONB NOT NULL DEFAULT '[]',
  priority INTEGER NOT NULL DEFAULT 100,
  reliability NUMERIC NOT NULL DEFAULT 0.5,
  enabled BOOLEAN NOT NULL DEFAULT TRUE
);
