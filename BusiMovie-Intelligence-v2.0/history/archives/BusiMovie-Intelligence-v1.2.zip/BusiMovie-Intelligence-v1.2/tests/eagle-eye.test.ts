import {describe,it,expect} from "vitest";
import {EagleEye} from "../src/eagle-eye.js";
describe("Eagle Eye",()=>{
 it("stores exact observed surface identity",()=>{
  const eye=new EagleEye();
  eye.observe({botUsername:"@x",chatId:"c",messageId:"42",buttons:[],observedAt:1,text:"x"});
  expect(eye.graph().surfaces[0].messageId).toBe("42");
 });
});
