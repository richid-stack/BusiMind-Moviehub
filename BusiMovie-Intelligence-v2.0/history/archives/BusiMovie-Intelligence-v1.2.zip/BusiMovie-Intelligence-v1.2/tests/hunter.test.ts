import {describe,it,expect} from "vitest";
import {MockTelegramGateway} from "../src/telegram.js";
import {InMemoryJobRepository} from "../src/repository.js";
import {Hunter} from "../src/hunter.js";
describe("hunter",()=>{
 it("verifies exact movie through typed movie route",async()=>{
  const repo=new InMemoryJobRepository();
  const hunter=new Hunter(new MockTelegramGateway(),repo);
  const job:any={id:"j",idempotencyKey:"k",request:{mediaType:"MOVIE",title:"The Incredible Hulk",year:2008},state:"CREATED"};
  const r=await hunter.hunt(job);
  expect(r.state).toBe("VERIFIED");
  expect(repo.correlations[0].botUsername).toBe("@Apple_moviebot");
 });
});
