import {describe,it,expect} from "vitest";
import {MockTelegramGateway} from "../src/telegram.js";

describe("Telegram correlation",()=>{
 it("anchors the response to the outbound message",async()=>{
  const g=new MockTelegramGateway();
  const c=await g.beginCorrelation("job","@Apple_moviebot");
  const sent=await g.sendMessage(c,"The Incredible Hulk");
  const surfaces=await g.observe(sent);
  expect(sent.outboundMessageId).toBe("outbound-1");
  expect(surfaces[0].replyToMessageId).toBe("outbound-1");
 });
});
