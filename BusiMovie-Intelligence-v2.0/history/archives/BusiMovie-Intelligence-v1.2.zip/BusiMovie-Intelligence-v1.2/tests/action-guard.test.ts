import {describe,it,expect} from "vitest";
import {assertBotAllowed,assertButtonAllowed} from "../src/action-guard.js";
describe("action guard",()=>{
 it("blocks movie from series bot",()=>expect(()=>assertBotAllowed(
  {request:{mediaType:"MOVIE"}} as any,{username:"@quinsonnbot",mediaType:"SERIES",priority:1,reliability:1,enabled:true}
 )).toThrow());
 it("blocks movie season navigation",()=>expect(()=>assertButtonAllowed(
  {request:{mediaType:"MOVIE"}} as any,{id:"1",label:"Season 1",kind:"SEASON_SELECT",row:0,column:0}
 )).toThrow());
});
