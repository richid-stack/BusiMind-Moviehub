import {describe,it,expect} from "vitest";
import {verifyCandidate,titleSimilarity} from "../src/identity.js";
describe("identity",()=>{
 it("rejects Hulk 2003 vs Incredible Hulk 2008",()=>{
  const x=verifyCandidate({mediaType:"MOVIE",title:"The Incredible Hulk",year:2008},{
   identity:{mediaType:"MOVIE",title:"Hulk",year:2003},confidence:.99,evidence:[]
  });
  expect(x.reason).toBe("CANONICAL_ID_MISMATCH");
 });
 it("rejects movie/series crossover",()=>{
  const x=verifyCandidate({mediaType:"MOVIE",title:"The Incredible Hulk",year:2008},{
   identity:{mediaType:"SERIES",title:"The Incredible Hulk",year:2008},confidence:.99,evidence:[]
  });
  expect(x.reason).toBe("MEDIA_TYPE_MISMATCH");
 });
 it("rejects wrong episode",()=>{
  const x=verifyCandidate({mediaType:"SERIES",title:"Show",year:2024,season:1,episode:2},{
   identity:{mediaType:"SERIES",title:"Show",year:2024,season:1,episode:1},confidence:.99,evidence:[]
  });
  expect(x.reason).toBe("EPISODE_MISMATCH");
 });
 it("keeps similarity below authority threshold for Hulk names",()=>{
  expect(titleSimilarity("Hulk","The Incredible Hulk")).toBeLessThan(.72);
 });
});
