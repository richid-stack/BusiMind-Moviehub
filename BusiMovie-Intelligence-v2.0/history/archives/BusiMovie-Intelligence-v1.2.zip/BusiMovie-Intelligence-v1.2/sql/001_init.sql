create table if not exists acquisition_jobs (
  id uuid primary key,
  idempotency_key text not null unique,
  media_type text not null check (media_type in ('MOVIE','SERIES')),
  requested_title text not null,
  requested_year int,
  season int,
  episode int,
  quality text,
  state text not null,
  failure_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists acquisition_events (
  id bigserial primary key,
  job_id uuid not null references acquisition_jobs(id) on delete cascade,
  event_type text not null,
  bot_username text,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists acquisition_events_job_idx
  on acquisition_events(job_id,id);

create table if not exists telegram_correlations (
  id uuid primary key,
  job_id uuid not null references acquisition_jobs(id) on delete cascade,
  bot_username text not null,
  chat_id text,
  outbound_message_id text,
  correlation_key text not null,
  started_at timestamptz not null,
  deadline_at timestamptz not null,
  completed_at timestamptz
);

create table if not exists telegram_observations (
  id bigserial primary key,
  correlation_id uuid references telegram_correlations(id) on delete set null,
  bot_username text not null,
  chat_id text not null,
  message_id text not null,
  reply_to_message_id text,
  text_content text,
  buttons jsonb not null default '[]'::jsonb,
  media jsonb,
  observed_at timestamptz not null default now(),
  unique(bot_username,chat_id,message_id)
);

create table if not exists bot_profiles (
  username text primary key,
  media_type text not null check(media_type in ('MOVIE','SERIES')),
  priority int not null,
  reliability numeric not null default .5,
  enabled boolean not null default true
);
