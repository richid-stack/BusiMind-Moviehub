# BusiMovie Intelligence V1.2 — Live Telegram Intelligence

V1.2 introduces the live Telegram transport and a strict conversation-correlation layer.

## What changed

### 1. Correlated conversations
Every outbound search receives a `CorrelationContext` containing:
- mission/job id
- bot username
- outbound message id
- start time
- response deadline

The observer only accepts messages that belong to the same bot/chat conversation and are newer than the correlation anchor. It does **not** ask Telegram for "the latest message" and assume it is the answer.

### 2. Eagle Eye live observation
The live adapter normalizes:
- message id
- reply-to id
- text
- media
- inline/reply buttons
- button row/column coordinates
- raw callback data where available

### 3. Exact button actions
Buttons are represented by stable observation ids and coordinates. Hunter can request an action against the exact observed message.

### 4. Recovery
Hunter records:
- bot attempt started
- outbound sent
- surfaces observed
- candidate rejected
- bot exhausted
- fallback attempted

A bot timeout/no-result therefore becomes a controlled failure that can move to the next eligible bot.

### 5. Session handling
`telegram:login` creates/saves a Teleproto StringSession. Treat the resulting session string like a password.

## Important

The live adapter is implemented, but it still requires **your Telegram API ID/hash and an authenticated account session**. The code cannot truthfully claim that a particular movie bot's current UI works until it is run against that bot.

Teleproto is used because the old `telegram`/GramJS npm package is archived; Teleproto is the maintained compatible continuation. The public GramJS API model remains the basis for the adapter.

## Setup

```bash
cp .env.example .env
npm install
npm run typecheck
npm test
```

For local Postgres/Redis:

```bash
docker compose up -d
```

Then configure:

```env
TELEGRAM_API_ID=...
TELEGRAM_API_HASH=...
TELEGRAM_SESSION=...
```

Generate a session:

```bash
npm run telegram:login
```

## Demo

```bash
npm run demo
```

The demo uses a deterministic mock gateway and does not touch Telegram.
