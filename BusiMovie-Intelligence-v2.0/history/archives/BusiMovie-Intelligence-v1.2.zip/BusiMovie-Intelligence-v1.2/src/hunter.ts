import { titleSimilarity, verifyCandidate } from "./identity.js";
import { assertBotAllowed, assertButtonAllowed } from "./action-guard.js";
import { eligibleBots } from "./bots.js";
import { JobStateMachine } from "./jobs.js";
import { EagleEye } from "./eagle-eye.js";
import type { AcquisitionJob, BotProfile, CanonicalIdentity, TelegramSurface } from "./domain.js";
import type { JobRepository } from "./repository.js";
import type { TelegramGateway } from "./telegram.js";

function candidate(job:AcquisitionJob,s:TelegramSurface){
  if(!s.text)return undefined;
  const title=s.text.split("\n")[0].trim();
  const year=s.text.match(/\b(19|20)\d{2}\b/)?.[0];
  const ep=s.text.match(/\bS(\d{1,2})E(\d{1,3})\b/i);
  const identity:CanonicalIdentity={
    mediaType:job.request.mediaType,title,year:year?Number(year):undefined,
    season:ep?Number(ep[1]):undefined,episode:ep?Number(ep[2]):undefined
  };
  return {identity,confidence:.9,evidence:[{source:`telegram:${s.botUsername}:${s.messageId}`,messageId:s.messageId}]};
}

export class Hunter{
  constructor(private gateway:TelegramGateway,private repo:JobRepository,private eye=new EagleEye()){}
  async hunt(job:AcquisitionJob,bots=eligibleBots(job.request.mediaType)){
    const sm=new JobStateMachine(job);
    await this.repo.create(job);
    await this.repo.event(job.id,"MISSION_CREATED",{request:job.request});
    sm.move("PLANNING");await this.repo.updateState(job.id,job.state);
    if(!bots.length){sm.move("FAILED","NO_ELIGIBLE_BOT");await this.repo.updateState(job.id,job.state,job.failureReason);return job}

    for(const bot of bots){
      assertBotAllowed(job,bot);
      sm.move("EXPLORING");await this.repo.updateState(job.id,job.state);
      await this.repo.event(job.id,"BOT_ATTEMPT_STARTED",{priority:bot.priority},bot.username);

      const correlation=await this.gateway.beginCorrelation(job.id,bot.username);
      await this.repo.correlation(correlation);
      await this.repo.event(job.id,"CORRELATION_OPENED",correlation,bot.username);

      const sent=await this.gateway.sendMessage(correlation,job.request.title);
      await this.repo.event(job.id,"OUTBOUND_SENT",{messageId:sent.outboundMessageId},bot.username);

      const surfaces=await this.gateway.observe(sent);
      if(!surfaces.length){
        await this.repo.event(job.id,"BOT_NO_RESULT",{reason:"timeout_or_no_correlated_surface"},bot.username);
        continue;
      }

      for(const raw of surfaces){
        const s=this.eye.observe(raw);
        await this.repo.observation(correlation.id,s);
        const c=candidate(job,s);
        if(!c)continue;

        sm.move("CANDIDATE_FOUND");await this.repo.updateState(job.id,job.state);
        sm.move("VERIFYING");await this.repo.updateState(job.id,job.state);
        const verdict=verifyCandidate(job.request,c);
        await this.repo.event(job.id,"VERIFICATION_RESULT",verdict,bot.username);

        if(verdict.ok){
          sm.move("VERIFIED");await this.repo.updateState(job.id,job.state);
          await this.repo.event(job.id,"ACQUISITION_VERIFIED",{messageId:s.messageId},bot.username);
          return job;
        }
        await this.repo.event(job.id,"CANDIDATE_REJECTED",{reason:verdict.reason},bot.username);
      }
      await this.repo.event(job.id,"BOT_ATTEMPT_EXHAUSTED",{},bot.username);
    }
    sm.move("FAILED","BOT_NO_RESULT");await this.repo.updateState(job.id,job.state,job.failureReason);
    return job;
  }
  graph(){return this.eye.graph()}
}
