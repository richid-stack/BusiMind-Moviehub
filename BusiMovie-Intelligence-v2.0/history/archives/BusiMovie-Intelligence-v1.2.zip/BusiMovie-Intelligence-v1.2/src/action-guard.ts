import type { AcquisitionJob, BotProfile, TelegramButton } from "./domain.js";
export function assertBotAllowed(job:AcquisitionJob,bot:BotProfile){
  if(job.request.mediaType!==bot.mediaType) throw new Error(`Action blocked: ${job.request.mediaType} cannot use ${bot.mediaType} bot`);
}
export function assertButtonAllowed(job:AcquisitionJob,b:TelegramButton){
  if(job.request.mediaType==="MOVIE" && (b.kind==="SEASON_SELECT"||b.kind==="EPISODE_SELECT"))
    throw new Error("Action blocked: movie cannot navigate seasons/episodes");
}
