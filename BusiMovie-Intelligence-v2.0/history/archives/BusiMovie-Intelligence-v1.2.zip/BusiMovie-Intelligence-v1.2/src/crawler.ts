import type { TelegramSurface } from "./domain.js";
import { parseTelegramEvidence } from "./identity.js";
export interface CrawlerSink{persist(surface:TelegramSurface,evidence:unknown[]):Promise<void>}
export class CrawlerEngine{
 constructor(private sink:CrawlerSink){}
 async ingest(s:TelegramSurface){
  const evidence=s.text?[parseTelegramEvidence(s.text)]:[];
  await this.sink.persist(s,evidence);return evidence;
 }
}
