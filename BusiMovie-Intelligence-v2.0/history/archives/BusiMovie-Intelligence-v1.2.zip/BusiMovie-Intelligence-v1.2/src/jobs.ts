import type { AcquisitionJob, AcquisitionState, FailureReason } from "./domain.js";
const allowed:Record<AcquisitionState,AcquisitionState[]>={
  CREATED:["PLANNING","FAILED"],PLANNING:["EXPLORING","FAILED"],
  EXPLORING:["CANDIDATE_FOUND","EXPLORING","FAILED"],CANDIDATE_FOUND:["VERIFYING","EXPLORING","FAILED"],
  VERIFYING:["VERIFIED","EXPLORING","FAILED"],VERIFIED:["FORWARDING","SUCCESS","FAILED"],
  FORWARDING:["INDEXING","FAILED"],INDEXING:["SUCCESS","FAILED"],SUCCESS:[],FAILED:["PLANNING","EXPLORING"]
};
export class JobStateMachine{
  constructor(public job:AcquisitionJob){}
  move(next:AcquisitionState,reason?:FailureReason){
    if(!allowed[this.job.state].includes(next))throw new Error(`Invalid transition ${this.job.state} -> ${next}`);
    this.job.state=next;this.job.failureReason=reason;return this.job;
  }
}
export function createIdempotencyKey(r:AcquisitionJob["request"]){
  return [r.mediaType,r.title.trim().toLowerCase(),r.year??"",r.season??"",r.episode??"",r.quality??""].join("|");
}
