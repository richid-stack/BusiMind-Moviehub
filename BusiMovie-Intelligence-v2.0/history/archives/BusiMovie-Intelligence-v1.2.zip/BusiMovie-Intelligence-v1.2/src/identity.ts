import type { AcquisitionJob, Candidate, MediaRequest, CanonicalIdentity } from "./domain.js";

export function normalizeTitle(input:string):string {
  return input.toLowerCase().replace(/[^\p{L}\p{N}]+/gu," ").replace(/\s+/g," ").trim();
}
export function titleSimilarity(a:string,b:string):number {
  const aa=new Set(normalizeTitle(a).split(" ")), bb=new Set(normalizeTitle(b).split(" "));
  if(!aa.size||!bb.size)return 0;
  const i=[...aa].filter(x=>bb.has(x)).length;
  return i/new Set([...aa,...bb]).size;
}
export interface Candidate { identity?: CanonicalIdentity; confidence:number; evidence:any[] }
export function verifyCandidate(request:MediaRequest,candidate:Candidate){
  const i=candidate.identity;
  if(!i)return {ok:false,reason:"AMBIGUOUS_METADATA"};
  if(i.mediaType!==request.mediaType)return {ok:false,reason:"MEDIA_TYPE_MISMATCH"};
  if(titleSimilarity(i.title,request.title)<.72)return {ok:false,reason:"CANONICAL_ID_MISMATCH"};
  if(request.year!==undefined && i.year!==request.year)return {ok:false,reason:"YEAR_MISMATCH"};
  if(request.mediaType==="MOVIE" && (i.season!==undefined||i.episode!==undefined))
    return {ok:false,reason:"MEDIA_TYPE_MISMATCH"};
  if(request.mediaType==="SERIES" && request.season!==undefined && i.season!==request.season)
    return {ok:false,reason:"SEASON_MISMATCH"};
  if(request.mediaType==="SERIES" && request.episode!==undefined && i.episode!==request.episode)
    return {ok:false,reason:"EPISODE_MISMATCH"};
  if(candidate.confidence<.72)return {ok:false,reason:"AMBIGUOUS_METADATA"};
  return {ok:true};
}
export function parseTelegramEvidence(text:string) {
  const year=text.match(/\b(19|20)\d{2}\b/)?.[0];
  const ep=text.match(/\bS(\d{1,2})E(\d{1,3})\b/i);
  return {
    title:text.split("\n")[0]?.trim(),
    year:year?Number(year):undefined,
    season:ep?Number(ep[1]):undefined,
    episode:ep?Number(ep[2]):undefined
  };
}
