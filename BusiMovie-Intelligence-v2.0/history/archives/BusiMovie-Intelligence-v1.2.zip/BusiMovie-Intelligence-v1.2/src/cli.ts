import { MediaRequest } from "./domain.js";
import { MockTelegramGateway } from "./telegram.js";
import { InMemoryJobRepository } from "./repository.js";
import { Hunter } from "./hunter.js";
import { createIdempotencyKey } from "./jobs.js";
import { randomUUID } from "node:crypto";

const request=MediaRequest.parse({mediaType:"MOVIE",title:"The Incredible Hulk",year:2008,quality:"1080p"});
const job={id:randomUUID(),idempotencyKey:createIdempotencyKey(request),request,state:"CREATED" as const};
const repo=new InMemoryJobRepository();
const hunter=new Hunter(new MockTelegramGateway(),repo);
const result=await hunter.hunt(job);
console.log(JSON.stringify({result,events:repo.events,correlations:repo.correlations,observations:repo.observations,graph:hunter.graph()},null,2));
