import { randomUUID } from "node:crypto";
import type { CorrelationContext, TelegramButton, TelegramSurface } from "./domain.js";

export interface TelegramGateway{
  beginCorrelation(jobId:string,bot:string):Promise<CorrelationContext>;
  sendMessage(c:CorrelationContext,text:string):Promise<CorrelationContext>;
  observe(c:CorrelationContext):Promise<TelegramSurface[]>;
  click(c:CorrelationContext,messageId:string,buttonId:string):Promise<TelegramSurface[]>;
  forward(bot:string,chatId:string,messageId:string,destination:string):Promise<void>;
}

export function classifyButton(label:string):TelegramButton["kind"]{
  const x=label.toLowerCase();
  if(/season|s\d{1,2}/.test(x))return "SEASON_SELECT";
  if(/episode|e\d{1,3}/.test(x))return "EPISODE_SELECT";
  if(/2160|1080|720|480|quality/.test(x))return "QUALITY_SELECT";
  if(/download|get file|file/.test(x))return "DOWNLOAD";
  if(/next|more|page/.test(x))return "PAGINATION_NEXT";
  if(/prev|back/.test(x))return "PAGINATION_PREVIOUS";
  if(/search|find/.test(x))return "SEARCH";
  return "MEDIA_CANDIDATE";
}

export class MockTelegramGateway implements TelegramGateway{
  async beginCorrelation(jobId:string,bot:string):Promise<CorrelationContext>{
    return {id:randomUUID(),jobId,botUsername:bot,chatId:"mock-chat",startedAt:Date.now(),deadlineAt:Date.now()+5000}
  }
  async sendMessage(c:CorrelationContext,_text:string){
    return {...c,outboundMessageId:"outbound-1"}
  }
  async observe(c:CorrelationContext){
    if(c.botUsername!=="@Apple_moviebot")return [];
    return [{
      botUsername:c.botUsername,chatId:c.chatId,messageId:"response-1",replyToMessageId:c.outboundMessageId,
      text:"The Incredible Hulk (2008)",buttons:[
        {id:"a",label:"The Incredible Hulk (2008)",kind:"MEDIA_CANDIDATE",row:0,column:0}
      ],observedAt:Date.now()
    }];
  }
  async click(){return []}
  async forward(){}
}

/**
 * Live Teleproto adapter.
 *
 * The adapter deliberately uses loose SDK typing at the boundary because
 * Telegram's generated TL types vary between compatible releases. The domain
 * layer remains strongly typed and receives only normalized surfaces.
 */
export interface TeleprotoClientLike{
  getEntity(peer:string):Promise<any>;
  sendMessage(peer:any,args:any):Promise<any>;
  getMessages(peer:any,args:any):Promise<any[]|any>;
  forwardMessages(destination:any,args:any):Promise<any>;
}

function normalizeMessage(bot:string,m:any):TelegramSurface{
  const rows:any[]=m?.buttons??[];
  const buttons:TelegramButton[]=[];
  for(let r=0;r<rows.length;r++){
    for(let col=0;col<(rows[r]?.length??0);col++){
      const b=rows[r][col];
      const label=String(b?.text??b?.label??"");
      buttons.push({
        id:`${m.id}:${r}:${col}`,
        label,
        kind:classifyButton(label),
        row:r,column:col,
        data:b?.data ? Buffer.from(b.data).toString("base64") : undefined
      });
    }
  }
  return {
    botUsername:bot,chatId:String(m?.chatId??m?.peerId??""),
    messageId:String(m?.id),replyToMessageId:m?.replyTo?.replyToMsgId?String(m.replyTo.replyToMsgId):undefined,
    text:m?.message??m?.text??undefined,buttons,
    media:m ? [{
      kind:m.document?"document":m.video?"video":m.photo?"photo":m.audio?"audio":"unknown",
      fileId:m.document?.id?String(m.document.id):undefined,
      fileName:undefined,mimeType:m.document?.mimeType
    }] : undefined,
    observedAt:Date.now()
  };
}

export class TeleprotoTelegramGateway implements TelegramGateway{
  constructor(private client:TeleprotoClientLike,private timeoutMs=12000,private pollMs=600){}
  async beginCorrelation(jobId:string,bot:string){
    const now=Date.now();
    return {id:randomUUID(),jobId,botUsername:bot,chatId:bot,startedAt:now,deadlineAt:now+this.timeoutMs};
  }
  async sendMessage(c:CorrelationContext,text:string){
    const entity=await this.client.getEntity(c.botUsername);
    const sent=await this.client.sendMessage(entity,{message:text});
    return {...c,chatId:String(sent?.chatId??c.chatId),outboundMessageId:String(sent?.id)};
  }
  async observe(c:CorrelationContext){
    const entity=await this.client.getEntity(c.botUsername);
    const minId=c.outboundMessageId?Number(c.outboundMessageId):0;
    const seen=new Map<string,TelegramSurface>();
    while(Date.now()<c.deadlineAt){
      const list=await this.client.getMessages(entity,{limit:25,minId});
      const messages=Array.isArray(list)?list:(list?.[Symbol.iterator]?Array.from(list):[]);
      for(const m of messages){
        const id=Number(m?.id??0);
        if(!id || id<=minId)continue;
        const surface=normalizeMessage(c.botUsername,m);
        if(surface.chatId!==c.chatId && c.chatId!==c.botUsername)continue;
        if(surface.replyToMessageId && surface.replyToMessageId!==c.outboundMessageId)continue;
        seen.set(surface.messageId,surface);
      }
      if(seen.size)return [...seen.values()];
      await new Promise(r=>setTimeout(r,this.pollMs));
    }
    return [];
  }
  async click(c:CorrelationContext,messageId:string,buttonId:string){
    const entity=await this.client.getEntity(c.botUsername);
    const messageList=await this.client.getMessages(entity,{ids:Number(messageId)});
    const message=Array.isArray(messageList)?messageList[0]:messageList?.[0];
    if(!message)throw new Error(`Observed message ${messageId} no longer exists`);
    const parts=buttonId.split(":");
    const row=Number(parts[1]),column=Number(parts[2]);
    await message.click(row,column);
    return this.observe({...c,outboundMessageId:messageId});
  }
  async forward(bot:string,chatId:string,messageId:string,destination:string){
    const source=await this.client.getEntity(chatId||bot);
    const target=await this.client.getEntity(destination);
    await this.client.forwardMessages(target,{messages:[Number(messageId)],fromPeer:source});
  }
}
