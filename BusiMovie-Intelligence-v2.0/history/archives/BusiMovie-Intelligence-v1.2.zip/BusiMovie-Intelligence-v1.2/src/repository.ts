import type { AcquisitionJob, AcquisitionState, TelegramSurface, CorrelationContext } from "./domain.js";
export interface JobRepository{
 create(job:AcquisitionJob):Promise<void>;
 updateState(id:string,state:AcquisitionState,reason?:string):Promise<void>;
 event(id:string,type:string,payload?:unknown,bot?:string):Promise<void>;
 correlation(c:CorrelationContext):Promise<void>;
 observation(correlationId:string,s:TelegramSurface):Promise<void>;
}
export class InMemoryJobRepository implements JobRepository{
 jobs=new Map<string,AcquisitionJob>();events:any[]=[];correlations:CorrelationContext[]=[];observations:TelegramSurface[]=[];
 async create(j:AcquisitionJob){this.jobs.set(j.id,structuredClone(j))}
 async updateState(id:string,state:AcquisitionState,reason?:string){const j=this.jobs.get(id);if(!j)throw Error("Job not found");j.state=state;j.failureReason=reason as any}
 async event(id:string,type:string,payload:any={},bot?:string){this.events.push({id,type,payload,bot})}
 async correlation(c:CorrelationContext){this.correlations.push(structuredClone(c))}
 async observation(_id:string,s:TelegramSurface){this.observations.push(structuredClone(s))}
}
