import type { BotProfile, MediaType } from "./domain.js";
export const DEFAULT_BOTS:BotProfile[]=[
 {username:"@Apple_moviebot",mediaType:"MOVIE",priority:1,reliability:.95,enabled:true},
 {username:"@iPapkornDeltaBot",mediaType:"MOVIE",priority:2,reliability:.80,enabled:true},
 {username:"@iPapkornEzPzBot",mediaType:"MOVIE",priority:3,reliability:.70,enabled:true},
 {username:"@quinsonnbot",mediaType:"SERIES",priority:1,reliability:.85,enabled:true}
];
export function eligibleBots(t:MediaType,b=DEFAULT_BOTS){return b.filter(x=>x.enabled&&x.mediaType===t).sort((a,c)=>a.priority-c.priority)}
