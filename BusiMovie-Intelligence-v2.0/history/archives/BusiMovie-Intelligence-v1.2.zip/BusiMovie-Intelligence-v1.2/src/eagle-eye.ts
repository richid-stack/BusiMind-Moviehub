import type { InteractionEdge, TelegramButton, TelegramSurface } from "./domain.js";
export class EagleEye {
  private surfaces=new Map<string,TelegramSurface>();
  private edges:InteractionEdge[]=[];
  observe(s:TelegramSurface){
    this.surfaces.set(`${s.botUsername}:${s.chatId}:${s.messageId}`,s); return s;
  }
  recordTransition(e:InteractionEdge){this.edges.push(e)}
  actionable(s:TelegramSurface){return s.buttons.filter(b=>b.kind!=="UNKNOWN")}
  graph(){return {surfaces:[...this.surfaces.values()],edges:[...this.edges]}}
}
