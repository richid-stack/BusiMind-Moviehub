import "dotenv/config";
import { TelegramClient, Api } from "teleproto";
import { StringSession } from "teleproto/sessions";
import { createInterface } from "node:readline/promises";

const rl=createInterface({input:process.stdin,output:process.stdout});
const apiId=Number(process.env.TELEGRAM_API_ID||0);
const apiHash=process.env.TELEGRAM_API_HASH||"";
if(!apiId||!apiHash)throw new Error("Set TELEGRAM_API_ID and TELEGRAM_API_HASH first");

const session=new StringSession(process.env.TELEGRAM_SESSION||"");
const client=new TelegramClient(session,apiId,apiHash,{connectionRetries:5});

await client.start({
 phoneNumber:async()=>process.env.TELEGRAM_PHONE||await rl.question("Phone: "),
 password:async()=>await rl.question("2FA password (blank if none): "),
 phoneCode:async()=>await rl.question("Telegram code: "),
 onError:(e)=>console.error(e)
});
console.log("\\nTELEGRAM_SESSION="+client.session.save());
await client.disconnect();
rl.close();
