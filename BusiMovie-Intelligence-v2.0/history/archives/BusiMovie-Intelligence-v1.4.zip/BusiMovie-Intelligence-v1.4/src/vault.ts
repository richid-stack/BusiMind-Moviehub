import { VaultKind, VerifiedAsset } from "./domain.js";

export interface VaultRecord {
  key: string;
  vault: VaultKind;
  canonicalId: string;
  assetFingerprint: string;
}

export class VaultIndex {
  private readonly records = new Map<string, VaultRecord>();

  put(asset: VerifiedAsset): VaultRecord {
    const key = `${asset.work.canonicalId}:${asset.asset.fingerprint}`;
    const record: VaultRecord = {
      key,
      vault: asset.vault,
      canonicalId: asset.work.canonicalId,
      assetFingerprint: asset.asset.fingerprint
    };
    this.records.set(key, record);
    return record;
  }

  list(vault?: VaultKind): VaultRecord[] {
    const all = [...this.records.values()];
    return vault ? all.filter(r => r.vault === vault) : all;
  }
}