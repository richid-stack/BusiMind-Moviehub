import { IntelligencePipeline } from "./pipeline.js";

const request = {
  canonicalId: "movie:the-incredible-hulk:2008",
  mediaType: "MOVIE" as const,
  title: "The Incredible Hulk",
  normalizedTitle: "the incredible hulk",
  year: 2008,
  alternateTitles: []
};

const pipeline = new IntelligencePipeline();

console.log(pipeline.verifyAttempt(request, {
  botUsername: "@Apple_moviebot",
  candidate: {
    source: "TELEGRAM",
    chatId: "movie-bot",
    messageId: "101",
    botUsername: "@Apple_moviebot",
    title: "The Incredible Hulk",
    year: 2008,
    mediaType: "MOVIE",
    rawLabels: ["The Incredible Hulk 2008", "1080p"],
    release: { quality: "1080p", releaseTags: ["1080p"], fileSize: 1000, filename: "The.Incredible.Hulk.2008.1080p.mkv" }
  }
}));

console.log(pipeline.verifyAttempt(request, {
  botUsername: "@quinsonnbot",
  candidate: {
    source: "TELEGRAM",
    chatId: "series-bot",
    messageId: "202",
    botUsername: "@quinsonnbot",
    title: "The Incredible Hulk",
    year: 2008,
    mediaType: "SERIES",
    rawLabels: ["The Incredible Hulk", "S01E01"]
  }
}));