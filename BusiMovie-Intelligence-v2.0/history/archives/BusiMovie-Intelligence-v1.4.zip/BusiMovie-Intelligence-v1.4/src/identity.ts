import { CanonicalWork, CandidateEvidence } from "./domain.js";
import { normalizeTitle } from "./normalize.js";

export type Resolution =
  | { kind: "MATCH"; work: CanonicalWork; confidence: number; evidence: string[] }
  | { kind: "MISMATCH"; confidence: number; evidence: string[] }
  | { kind: "UNKNOWN"; confidence: number; evidence: string[] };

export class IdentityResolver {
  resolve(request: CanonicalWork, candidate: CandidateEvidence): Resolution {
    const evidence: string[] = [];

    if (candidate.mediaType && candidate.mediaType !== request.mediaType) {
      evidence.push(`media type mismatch: requested=${request.mediaType}, candidate=${candidate.mediaType}`);
      return { kind: "MISMATCH", confidence: 1, evidence };
    }

    if (request.mediaType === "MOVIE" && candidate.episode) {
      evidence.push("candidate contains episode identity for a movie request");
      return { kind: "MISMATCH", confidence: 1, evidence };
    }

    if (candidate.canonicalId) {
      if (candidate.canonicalId === request.canonicalId) {
        evidence.push("canonical ID matches");
        return { kind: "MATCH", work: request, confidence: 1, evidence };
      }
      evidence.push(`canonical ID mismatch: requested=${request.canonicalId}, candidate=${candidate.canonicalId}`);
      return { kind: "MISMATCH", confidence: 1, evidence };
    }

    if (!candidate.title) {
      evidence.push("candidate has no title");
      return { kind: "UNKNOWN", confidence: 0, evidence };
    }

    const titleMatch = normalizeTitle(candidate.title) === request.normalizedTitle ||
      request.alternateTitles.some(t => normalizeTitle(t) === normalizeTitle(candidate.title));

    if (!titleMatch) {
      evidence.push(`title mismatch: requested="${request.title}", candidate="${candidate.title}"`);
      return { kind: "MISMATCH", confidence: 0.99, evidence };
    }

    evidence.push("title matches");

    if (candidate.year !== undefined && request.year !== undefined) {
      if (candidate.year !== request.year) {
        evidence.push(`year mismatch: requested=${request.year}, candidate=${candidate.year}`);
        return { kind: "MISMATCH", confidence: 0.99, evidence };
      }
      evidence.push("year matches");
      return { kind: "MATCH", work: request, confidence: 0.98, evidence };
    }

    evidence.push("year not available on both sides");
    return { kind: "UNKNOWN", confidence: 0.65, evidence };
  }
}