import {
  AssetFingerprint,
  CandidateEvidence,
  CanonicalWork,
  VerificationDecision,
  VerifiedAsset
} from "./domain.js";
import { IdentityResolver } from "./identity.js";

export class VerificationCore {
  constructor(private readonly resolver = new IdentityResolver()) {}

  verify(request: CanonicalWork, candidate: CandidateEvidence, duplicate = false): VerificationDecision {
    if (duplicate) {
      return {
        status: "REJECTED",
        reason: "DUPLICATE_ASSET",
        confidence: 1,
        requestedId: request.canonicalId,
        candidateId: candidate.canonicalId,
        evidence: ["asset fingerprint already exists"]
      };
    }

    const result = this.resolver.resolve(request, candidate);

    if (result.kind === "MATCH") {
      return {
        status: "VERIFIED",
        reason: "MATCH",
        confidence: result.confidence,
        requestedId: request.canonicalId,
        candidateId: candidate.canonicalId,
        evidence: result.evidence
      };
    }

    if (result.kind === "MISMATCH") {
      const reason =
        candidate.mediaType && candidate.mediaType !== request.mediaType
          ? "MEDIA_TYPE_MISMATCH"
          : candidate.episode && request.mediaType === "MOVIE"
            ? "EPISODE_FOR_MOVIE"
            : candidate.year !== undefined && request.year !== undefined && candidate.year !== request.year
              ? "DIFFERENT_YEAR"
              : "DIFFERENT_WORK";

      return {
        status: "REJECTED",
        reason,
        confidence: result.confidence,
        requestedId: request.canonicalId,
        candidateId: candidate.canonicalId,
        evidence: result.evidence
      };
    }

    return {
      status: "UNKNOWN",
      reason: "INSUFFICIENT_IDENTITY_EVIDENCE",
      confidence: result.confidence,
      requestedId: request.canonicalId,
      candidateId: candidate.canonicalId,
      evidence: result.evidence
    };
  }

  toVerifiedAsset(
    request: CanonicalWork,
    candidate: CandidateEvidence,
    asset: AssetFingerprint
  ): VerifiedAsset {
    if (request.mediaType === "MOVIE") {
      return { work: request, asset, release: candidate.release, vault: "MOVIE_VAULT" };
    }
    return { work: request, asset, release: candidate.release, vault: "SERIES_VAULT" };
  }
}