import { createHash } from "node:crypto";
import { AssetFingerprint } from "./domain.js";

export function fingerprintAsset(input: Omit<AssetFingerprint, "fingerprint">): AssetFingerprint {
  const stable = [
    input.source.chatId,
    input.source.messageId,
    input.size ?? "",
    input.mimeType ?? "",
    input.filename ?? ""
  ].join("|");

  const fingerprint = createHash("sha256").update(stable).digest("hex");

  return { ...input, fingerprint };
}

export class FingerprintIndex {
  private readonly seen = new Set<string>();

  has(fingerprint: string): boolean {
    return this.seen.has(fingerprint);
  }

  add(fingerprint: string): void {
    this.seen.add(fingerprint);
  }
}