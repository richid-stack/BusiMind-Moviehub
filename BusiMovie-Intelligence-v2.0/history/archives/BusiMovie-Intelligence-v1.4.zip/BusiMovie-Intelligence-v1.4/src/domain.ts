export type MediaType = "MOVIE" | "SERIES" | "EPISODE";

export type IdentityStatus = "VERIFIED" | "UNKNOWN" | "REJECTED";

export interface CanonicalWork {
  canonicalId: string;
  mediaType: "MOVIE" | "SERIES";
  title: string;
  normalizedTitle: string;
  year?: number;
  alternateTitles: string[];
  franchiseId?: string;
  parentSeriesId?: string;
}

export interface RequestedMedia {
  requestId: string;
  canonical: CanonicalWork;
}

export interface EpisodeIdentity {
  season: number;
  episode: number;
  seriesCanonicalId: string;
}

export interface ReleaseEvidence {
  quality?: string;
  sourceTitle?: string;
  filename?: string;
  fileSize?: number;
  mimeType?: string;
  releaseTags: string[];
}

export interface CandidateEvidence {
  source: "TELEGRAM" | "CATALOG" | "USER";
  chatId?: string;
  messageId?: string;
  botUsername?: string;
  title?: string;
  year?: number;
  mediaType?: MediaType;
  canonicalId?: string;
  episode?: EpisodeIdentity;
  release?: ReleaseEvidence;
  rawLabels: string[];
}

export type VerificationReason =
  | "MATCH"
  | "MEDIA_TYPE_MISMATCH"
  | "DIFFERENT_WORK"
  | "DIFFERENT_YEAR"
  | "EPISODE_FOR_MOVIE"
  | "SERIES_FOR_MOVIE"
  | "MOVIE_FOR_SERIES"
  | "AMBIGUOUS_TITLE"
  | "INSUFFICIENT_IDENTITY_EVIDENCE"
  | "CANONICAL_ID_MISMATCH"
  | "DUPLICATE_ASSET";

export interface VerificationDecision {
  status: IdentityStatus;
  reason: VerificationReason;
  confidence: number;
  requestedId: string;
  candidateId?: string;
  evidence: string[];
}

export interface AssetFingerprint {
  fingerprint: string;
  source: {
    chatId: string;
    messageId: string;
    botUsername?: string;
  };
  size?: number;
  mimeType?: string;
  filename?: string;
}

export type VaultKind = "MOVIE_VAULT" | "SERIES_VAULT";

export interface VerifiedAsset {
  work: CanonicalWork;
  asset: AssetFingerprint;
  release?: ReleaseEvidence;
  vault: VaultKind;
}
