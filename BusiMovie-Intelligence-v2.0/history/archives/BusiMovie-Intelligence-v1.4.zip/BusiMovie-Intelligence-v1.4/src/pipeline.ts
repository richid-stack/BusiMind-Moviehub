import { CandidateEvidence, CanonicalWork, VerificationDecision, VerifiedAsset } from "./domain.js";
import { fingerprintAsset, FingerprintIndex } from "./fingerprint.js";
import { VerificationCore } from "./verification.js";
import { VaultIndex } from "./vault.js";

export interface AcquisitionAttempt {
  botUsername: string;
  candidate: CandidateEvidence;
}

export class IntelligencePipeline {
  private readonly verifier = new VerificationCore();
  private readonly fingerprints = new FingerprintIndex();
  readonly vault = new VaultIndex();

  verifyAttempt(request: CanonicalWork, attempt: AcquisitionAttempt): VerificationDecision {
    const assetInput = attempt.candidate.chatId && attempt.candidate.messageId
      ? fingerprintAsset({
          source: {
            chatId: attempt.candidate.chatId,
            messageId: attempt.candidate.messageId,
            botUsername: attempt.botUsername
          },
          size: attempt.candidate.release?.fileSize,
          mimeType: attempt.candidate.release?.mimeType,
          filename: attempt.candidate.release?.filename
        })
      : undefined;

    const duplicate = assetInput ? this.fingerprints.has(assetInput.fingerprint) : false;
    const decision = this.verifier.verify(request, attempt.candidate, duplicate);

    if (decision.status === "VERIFIED" && assetInput) {
      this.fingerprints.add(assetInput.fingerprint);
      const verified: VerifiedAsset = this.verifier.toVerifiedAsset(request, attempt.candidate, assetInput);
      this.vault.put(verified);
    }

    return decision;
  }
}