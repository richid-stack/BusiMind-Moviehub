import { describe, expect, it } from "vitest";
import { VerificationCore } from "../src/verification.js";

const core = new VerificationCore();
const movie = {
  canonicalId: "movie:the-incredible-hulk:2008",
  mediaType: "MOVIE" as const,
  title: "The Incredible Hulk",
  normalizedTitle: "the incredible hulk",
  year: 2008,
  alternateTitles: []
};

describe("verification core", () => {
  it("routes verified movie to movie vault", () => {
    const candidate = {
      source: "TELEGRAM" as const,
      chatId: "c",
      messageId: "1",
      title: "The Incredible Hulk",
      year: 2008,
      mediaType: "MOVIE" as const,
      rawLabels: []
    };
    const d = core.verify(movie, candidate);
    expect(d.status).toBe("VERIFIED");
    expect(core.toVerifiedAsset(movie, candidate, {
      fingerprint: "abc",
      source: { chatId: "c", messageId: "1" }
    }).vault).toBe("MOVIE_VAULT");
  });

  it("hard rejects movie/series crossover", () => {
    const d = core.verify(movie, {
      source: "TELEGRAM",
      title: "The Incredible Hulk",
      year: 2008,
      mediaType: "SERIES",
      rawLabels: []
    });
    expect(d.status).toBe("REJECTED");
    expect(d.reason).toBe("MEDIA_TYPE_MISMATCH");
  });

  it("rejects an episode for a movie", () => {
    const d = core.verify(movie, {
      source: "TELEGRAM",
      title: "The Incredible Hulk",
      mediaType: "MOVIE",
      episode: { season: 1, episode: 1, seriesCanonicalId: "series:ih" },
      rawLabels: ["S01E01"]
    });
    expect(d.status).toBe("REJECTED");
    expect(d.reason).toBe("EPISODE_FOR_MOVIE");
  });
});