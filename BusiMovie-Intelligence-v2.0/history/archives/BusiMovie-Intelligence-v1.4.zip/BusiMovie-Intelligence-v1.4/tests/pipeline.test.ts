import { describe, expect, it } from "vitest";
import { IntelligencePipeline } from "../src/pipeline.js";

const request = {
  canonicalId: "movie:the-incredible-hulk:2008",
  mediaType: "MOVIE" as const,
  title: "The Incredible Hulk",
  normalizedTitle: "the incredible hulk",
  year: 2008,
  alternateTitles: []
};

describe("end-to-end identity pipeline", () => {
  it("verifies, fingerprints and indexes a valid asset", () => {
    const p = new IntelligencePipeline();
    const d = p.verifyAttempt(request, {
      botUsername: "@Apple_moviebot",
      candidate: {
        source: "TELEGRAM",
        chatId: "apple",
        messageId: "99",
        title: "The Incredible Hulk",
        year: 2008,
        mediaType: "MOVIE",
        rawLabels: ["1080p"],
        release: { quality: "1080p", releaseTags: ["1080p"], filename: "ih.2008.1080p.mkv" }
      }
    });
    expect(d.status).toBe("VERIFIED");
    expect(p.vault.list("MOVIE_VAULT")).toHaveLength(1);
  });

  it("does not ingest the same Telegram asset twice", () => {
    const p = new IntelligencePipeline();
    const attempt = {
      botUsername: "@Apple_moviebot",
      candidate: {
        source: "TELEGRAM" as const,
        chatId: "apple",
        messageId: "99",
        title: "The Incredible Hulk",
        year: 2008,
        mediaType: "MOVIE" as const,
        rawLabels: [],
      }
    };
    expect(p.verifyAttempt(request, attempt).status).toBe("VERIFIED");
    expect(p.verifyAttempt(request, attempt).status).toBe("REJECTED");
    expect(p.vault.list()).toHaveLength(1);
  });
});