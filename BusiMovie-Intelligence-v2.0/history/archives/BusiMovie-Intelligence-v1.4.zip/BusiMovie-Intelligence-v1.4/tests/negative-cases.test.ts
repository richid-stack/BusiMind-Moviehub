import { describe, expect, it } from "vitest";
import { VerificationCore } from "../src/verification.js";

const core = new VerificationCore();
const movie = {
  canonicalId: "movie:the-incredible-hulk:2008",
  mediaType: "MOVIE" as const,
  title: "The Incredible Hulk",
  normalizedTitle: "the incredible hulk",
  year: 2008,
  alternateTitles: []
};

describe("negative identity cases", () => {
  it("rejects wrong year even when title looks right", () => {
    const d = core.verify(movie, {
      source: "TELEGRAM",
      title: "The Incredible Hulk",
      year: 2012,
      mediaType: "MOVIE",
      rawLabels: []
    });
    expect(d.status).toBe("REJECTED");
    expect(d.reason).toBe("DIFFERENT_YEAR");
  });

  it("returns unknown rather than inventing identity", () => {
    const d = core.verify(movie, {
      source: "TELEGRAM",
      title: "The Incredible Hulk",
      mediaType: "MOVIE",
      rawLabels: []
    });
    expect(d.status).toBe("UNKNOWN");
  });

  it("canonical IDs outrank matching display text", () => {
    const d = core.verify(movie, {
      source: "TELEGRAM",
      title: "The Incredible Hulk",
      year: 2008,
      mediaType: "MOVIE",
      canonicalId: "movie:some-other-work:2008",
      rawLabels: []
    });
    expect(d.status).toBe("REJECTED");
    expect(d.reason).toBe("CANONICAL_ID_MISMATCH");
  });
});