import { describe, expect, it } from "vitest";
import { IdentityResolver } from "../src/identity.js";

const resolver = new IdentityResolver();

const incredibleHulk = {
  canonicalId: "movie:the-incredible-hulk:2008",
  mediaType: "MOVIE" as const,
  title: "The Incredible Hulk",
  normalizedTitle: "the incredible hulk",
  year: 2008,
  alternateTitles: []
};

describe("canonical identity", () => {
  it("accepts the exact movie", () => {
    const r = resolver.resolve(incredibleHulk, {
      source: "TELEGRAM",
      title: "The Incredible Hulk",
      year: 2008,
      mediaType: "MOVIE",
      rawLabels: []
    });
    expect(r.kind).toBe("MATCH");
  });

  it("rejects Hulk 2003 as a different work", () => {
    const r = resolver.resolve(incredibleHulk, {
      source: "TELEGRAM",
      title: "Hulk",
      year: 2003,
      mediaType: "MOVIE",
      rawLabels: []
    });
    expect(r.kind).toBe("MISMATCH");
  });

  it("rejects a series result for a movie request", () => {
    const r = resolver.resolve(incredibleHulk, {
      source: "TELEGRAM",
      title: "The Incredible Hulk",
      year: 2008,
      mediaType: "SERIES",
      rawLabels: []
    });
    expect(r.kind).toBe("MISMATCH");
  });

  it("does not guess when the year is missing", () => {
    const r = resolver.resolve(incredibleHulk, {
      source: "TELEGRAM",
      title: "The Incredible Hulk",
      mediaType: "MOVIE",
      rawLabels: []
    });
    expect(r.kind).toBe("UNKNOWN");
  });
});