# BusiMovie Intelligence V1.4

V1.4 adds the canonical identity and verification layer that sits **before**
acquisition and vault ingestion.

## Golden rule

> Raw Telegram content is evidence. It is never authoritative identity.

The pipeline is:

Search request
→ canonical request identity
→ media-type gate
→ acquisition candidate
→ identity resolution
→ verification
→ asset fingerprint
→ vault placement
→ index

### What this version solves

- `Hulk (2003)` and `The Incredible Hulk (2008)` are different canonical works.
- MOVIE and SERIES are hard-separated.
- A series/episode result cannot satisfy a movie request.
- A movie result cannot satisfy a series request.
- Ambiguous identity is `UNKNOWN`, not a guess.
- Release/quality is kept separate from work identity.
- Telegram chat/message identity becomes provenance.
- Duplicate assets can be detected without changing canonical identity.
- Every verification decision has machine-readable evidence and reasons.

### Important

This version is deliberately transport-independent. It does not replace the
V1.3 Telegram layer. The identity/verification contracts can be connected to
the existing Hunter later.

## Example

`The Incredible Hulk (2008)` + candidate `The Incredible Hulk (2008)`
→ ACCEPT

`The Incredible Hulk (2008)` + candidate `Hulk (2003)`
→ REJECT / DIFFERENT_WORK

`The Incredible Hulk (2008)` + candidate series
→ REJECT / MEDIA_TYPE_MISMATCH

`The Incredible Hulk (2008)` + candidate with unclear year/type
→ UNKNOWN / INSUFFICIENT_IDENTITY_EVIDENCE
