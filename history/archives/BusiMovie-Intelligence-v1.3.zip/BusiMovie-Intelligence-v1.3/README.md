# BusiMovie Intelligence V1.3 — Adaptive Hunter

V1.3 turns Eagle Eye + Hunter into a bounded state-aware navigation engine.

## Core idea

Telegram is not a fixed UI. A bot can return:
- a search result
- a season selector
- an episode selector
- a quality selector
- a download/file message
- pagination
- a retry/search prompt
- an unexpected surface

Eagle Eye classifies the observed surface. Hunter decides which actions are legal for the mission, executes one bounded action at a time, records the transition, and evaluates the resulting surface.

## Safety model

The reasoner can recommend an action, but it cannot override:
- media type
- season/episode constraints
- correlation boundaries
- maximum navigation depth
- repeated-action loop protection
- verification gates

UNKNOWN is a valid state.

## Mission lifecycle

```text
MISSION
  -> OBSERVE
  -> INTERPRET
  -> PLAN ACTION
  -> GUARD
  -> EXECUTE
  -> OBSERVE RESULT
  -> VERIFY
  -> COMPLETE / RECOVER / FAIL
```

## New V1.3 capabilities

- Surface classification
- Action scoring
- deterministic bounded planner
- loop detection
- repeated-surface detection
- action budget
- recovery policy
- transition graph
- mission trace
- explicit terminal conditions
- no fake episode assignment
- no movie -> season navigation

The LLM can later replace the planner's recommendation component without becoming the authority over safety or identity.
