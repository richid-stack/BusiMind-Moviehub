import {describe,it,expect} from "vitest";
import {EagleEye} from "../src/eagle-eye.js";
describe("Eagle Eye interpretation",()=>{
 const eye=new EagleEye();
 it("recognizes season selector",()=>{
  const s:any={botUsername:"@q",chatId:"c",messageId:"1",text:"Choose season",buttons:[
   {id:"s1",label:"Season 1",kind:"",row:0,column:0}],observedAt:1};
  expect(eye.interpret(s,"Show").kind).toBe("SEASON_SELECTOR");
 });
 it("recognizes quality selector",()=>{
  const s:any={botUsername:"@m",chatId:"c",messageId:"2",text:"Choose quality",buttons:[
   {id:"q",label:"1080p",kind:"",row:0,column:0}],observedAt:1};
  expect(eye.interpret(s,"Movie").kind).toBe("QUALITY_SELECTOR");
 });
});
