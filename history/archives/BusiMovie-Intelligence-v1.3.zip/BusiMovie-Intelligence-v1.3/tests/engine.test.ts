import {describe,it,expect} from "vitest";
import {AdaptiveHunter} from "../src/engine.js";
import {MockAdaptiveGateway} from "../src/mock.js";
describe("adaptive hunter",()=>{
 it("observes, acts, then reaches the next surface",async()=>{
  const job:any={id:"j",request:{mediaType:"MOVIE",title:"The Incredible Hulk",year:2008},state:"CREATED"};
  const r=await new AdaptiveHunter(new MockAdaptiveGateway()).run(job);
  expect(r.reason).toBe("DOWNLOAD_SURFACE_REACHED");
  expect(r.graph.transitions.length).toBeGreaterThan(0);
 });
});
