import {describe,it,expect} from "vitest";
import {AdaptiveHunter,NavigationGateway} from "../src/engine.js";
describe("loop protection",()=>{
 it("stops repeated surfaces",async()=>{
  const gateway:NavigationGateway={
   async observe(){return [{botUsername:"@m",chatId:"c",messageId:"same",text:"X",buttons:[
    {id:"x",label:"X",kind:"SELECT_MEDIA",row:0,column:0}],observedAt:1}]},
   async click(_j,s){return [s]}
  };
  const job:any={id:"j",request:{mediaType:"MOVIE",title:"X"},state:"CREATED"};
  const r=await new AdaptiveHunter(gateway).run(job);
  expect(r.reason).toBe("REPEATED_SURFACE");
 });
});
