import {describe,it,expect} from "vitest";
import {legalButton} from "../src/guard.js";
describe("guard",()=>{
 it("blocks movie season button",()=>{
  const r=legalButton({request:{mediaType:"MOVIE"}} as any,{id:"1",label:"Season 1",kind:"",row:0,column:0});
  expect(r.ok).toBe(false);
 });
});
