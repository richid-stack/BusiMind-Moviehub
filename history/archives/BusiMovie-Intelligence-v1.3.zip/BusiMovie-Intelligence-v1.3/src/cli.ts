import {AdaptiveHunter} from "./engine.js";
import {MockAdaptiveGateway} from "./mock.js";
const job:any={id:"demo",request:{mediaType:"MOVIE",title:"The Incredible Hulk",year:2008,quality:"1080p"},state:"CREATED"};
const r=await new AdaptiveHunter(new MockAdaptiveGateway()).run(job);
console.log(JSON.stringify(r,null,2));
