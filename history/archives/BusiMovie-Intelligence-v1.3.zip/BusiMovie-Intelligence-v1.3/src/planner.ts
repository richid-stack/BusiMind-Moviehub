import type {Action,Job,Interpretation,Surface} from "./domain.js";
import {legal} from "./guard.js";

export interface Planner{choose(job:Job,surface:Surface,i:Interpretation,actions:Action[]):Action|undefined}

export class DeterministicPlanner implements Planner{
 choose(job,surface,_i,actions){
  for(const a of actions){
   if(!legal(job,a).ok)continue;
   if(a.kind==="DOWNLOAD")return a;
   if(a.kind==="SELECT_QUALITY"&&job.request.quality)return a;
   if(a.kind==="SELECT_EPISODE"&&job.request.episode)return a;
   if(a.kind==="SELECT_SEASON"&&job.request.season)return a;
   if(a.kind==="SELECT_MEDIA")return a;
  }
  return actions.find(a=>legal(job,a).ok);
 }
}
