import type {MediaRequest} from "./domain.js";

export function normalizeTitle(s:string){
 return s.toLowerCase().replace(/[^\p{L}\p{N}]+/gu," ").replace(/\s+/g," ").trim();
}
export function similarity(a:string,b:string){
 const A=new Set(normalizeTitle(a).split(" ")),B=new Set(normalizeTitle(b).split(" "));
 if(!A.size||!B.size)return 0;
 return [...A].filter(x=>B.has(x)).length/new Set([...A,...B]).size;
}
export function verify(request:MediaRequest,c:{mediaType:"MOVIE"|"SERIES";title:string;year?:number;season?:number;episode?:number}){
 if(c.mediaType!==request.mediaType)return {ok:false,reason:"MEDIA_TYPE_MISMATCH"};
 if(similarity(c.title,request.title)<.72)return {ok:false,reason:"CANONICAL_ID_MISMATCH"};
 if(request.year!==undefined&&c.year!==request.year)return {ok:false,reason:"YEAR_MISMATCH"};
 if(request.mediaType==="MOVIE"&&(c.season!==undefined||c.episode!==undefined))return {ok:false,reason:"MEDIA_TYPE_MISMATCH"};
 if(request.season!==undefined&&c.season!==request.season)return {ok:false,reason:"SEASON_MISMATCH"};
 if(request.episode!==undefined&&c.episode!==request.episode)return {ok:false,reason:"EPISODE_MISMATCH"};
 return {ok:true};
}
export function extract(text:string){
 const first=text.split("\n")[0]?.trim()??"";
 const year=text.match(/\b(19|20)\d{2}\b/)?.[0];
 const ep=text.match(/\bS(\d{1,2})E(\d{1,3})\b/i);
 const quality=text.match(/\b(2160p|1080p|720p|480p)\b/i)?.[1];
 return {title:first,year:year?Number(year):undefined,season:ep?Number(ep[1]):undefined,episode:ep?Number(ep[2]):undefined,quality};
}
