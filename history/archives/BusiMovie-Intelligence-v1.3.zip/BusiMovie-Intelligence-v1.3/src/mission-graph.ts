import type {Action,Transition,Surface} from "./domain.js";

export class MissionGraph{
 surfaces=new Map<string,Surface>();
 transitions:Transition[]=[];
 private counts=new Map<string,number>();
 addSurface(s:Surface){
  const key=`${s.botUsername}:${s.chatId}:${s.messageId}`;
  this.surfaces.set(key,s);
  return key;
 }
 addTransition(t:Transition){
  this.transitions.push(t);
  const k=`${t.fromMessageId}|${t.action.kind}|${t.action.buttonId??""}`;
  this.counts.set(k,(this.counts.get(k)??0)+1);
 }
 repeatedAction(t:Transition,max:number){
  const k=`${t.fromMessageId}|${t.action.kind}|${t.action.buttonId??""}`;
  return (this.counts.get(k)??0)>=max;
 }
 surfaceSeen(messageId:string){return [...this.surfaces.values()].some(s=>s.messageId===messageId)}
 snapshot(){return {surfaces:[...this.surfaces.values()],transitions:[...this.transitions]}}
}
