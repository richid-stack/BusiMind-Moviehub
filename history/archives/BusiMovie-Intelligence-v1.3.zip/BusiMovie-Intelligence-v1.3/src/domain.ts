export type MediaType="MOVIE"|"SERIES";

export type SurfaceKind=
 |"SEARCH_RESULTS"|"MEDIA_DETAIL"|"SEASON_SELECTOR"|"EPISODE_SELECTOR"
 |"QUALITY_SELECTOR"|"DOWNLOAD_SURFACE"|"PAGINATION"|"NO_RESULT"
 |"ERROR_SURFACE"|"UNKNOWN";

export type ActionKind=
 |"SELECT_MEDIA"|"SELECT_SEASON"|"SELECT_EPISODE"|"SELECT_QUALITY"
 |"DOWNLOAD"|"NEXT_PAGE"|"PREVIOUS_PAGE"|"RETRY_SEARCH"|"NOOP";

export interface MediaRequest{
 mediaType:MediaType; title:string; year?:number; season?:number; episode?:number; quality?:string;
}

export interface Job{
 id:string; request:MediaRequest; state:"CREATED"|"EXPLORING"|"VERIFYING"|"VERIFIED"|"FAILED";
}

export interface Button{
 id:string; label:string; kind:string; row:number; column:number; data?:string;
}

export interface Surface{
 botUsername:string; chatId:string; messageId:string; replyToMessageId?:string;
 text?:string; buttons:Button[]; observedAt:number;
}

export interface Interpretation{
 kind:SurfaceKind;
 confidence:number;
 title?:string;
 year?:number;
 season?:number;
 episode?:number;
 quality?:string;
 rationale:string[];
}

export interface Action{
 kind:ActionKind;
 buttonId?:string;
 label?:string;
 score:number;
 rationale:string[];
}

export interface Transition{
 fromMessageId:string;
 action:Action;
 toMessageIds:string[];
 at:number;
}

export interface MissionPolicy{
 maxSteps:number;
 maxRepeatedSurface:number;
 maxSameAction:number;
 timeoutMs:number;
}

export interface MissionTrace{
 step:number;
 surfaceId:string;
 interpretation:Interpretation;
 chosenAction?:Action;
 resultIds?:string[];
}
