import {EagleEye} from "./eagle-eye.js";
import {DeterministicPlanner,Planner} from "./planner.js";
import {MissionGraph} from "./mission-graph.js";
import type {Job,Surface,Action,MissionPolicy,MissionTrace} from "./domain.js";
import {legalButton} from "./guard.js";

export interface NavigationGateway{
 observe(job:Job):Promise<Surface[]>;
 click(job:Job,surface:Surface,buttonId:string):Promise<Surface[]>;
}

export class AdaptiveHunter{
 readonly eye=new EagleEye();
 readonly graph=new MissionGraph();
 readonly trace:MissionTrace[]=[];
 constructor(private gateway:NavigationGateway,private planner:Planner=new DeterministicPlanner(),
   private policy:MissionPolicy={maxSteps:12,maxRepeatedSurface:2,maxSameAction:2,timeoutMs:12000}){}

 async run(job:Job){
  let surfaces=await this.gateway.observe(job);
  const seen=new Map<string,number>();
  for(let step=0;step<this.policy.maxSteps;step++){
   if(!surfaces.length){job.state="FAILED";return {job,reason:"NO_SURFACE"}}
   let progressed=false;
   for(const raw of surfaces){
    const surface=this.eye.classifyButtons(raw);
    this.graph.addSurface(surface);
    const key=`${surface.botUsername}:${surface.chatId}:${surface.messageId}`;
    const n=(seen.get(key)??0)+1;seen.set(key,n);
    const interpretation=this.eye.interpret(surface,job.request.title);
    const actions=this.eye.actions(surface,interpretation);

    if(n>this.policy.maxRepeatedSurface){
      job.state="FAILED";return {job,reason:"REPEATED_SURFACE",trace:this.trace,graph:this.graph.snapshot()};
    }

    if(interpretation.kind==="DOWNLOAD_SURFACE"){
      job.state="VERIFYING";
      this.trace.push({step,surfaceId:key,interpretation});
      return {job,reason:"DOWNLOAD_SURFACE_REACHED",trace:this.trace,graph:this.graph.snapshot()};
    }

    const action=this.planner.choose(job,surface,interpretation,actions);
    this.trace.push({step,surfaceId:key,interpretation,chosenAction:action});

    if(!action){continue}
    const btn=surface.buttons.find(b=>b.id===action.buttonId);
    if(btn&&!legalButton(job,btn).ok)continue;

    const next=await this.gateway.click(job,surface,action.buttonId!);
    const transition={fromMessageId:surface.messageId,action,toMessageIds:next.map(x=>x.messageId),at:Date.now()};
    this.graph.addTransition(transition);

    if(this.graph.repeatedAction(transition,this.policy.maxSameAction)){
      job.state="FAILED";return {job,reason:"ACTION_LOOP",trace:this.trace,graph:this.graph.snapshot()};
    }
    surfaces=next;progressed=true;break;
   }
   if(progressed)continue;
   job.state="FAILED";return {job,reason:"NO_LEGAL_PROGRESS",trace:this.trace,graph:this.graph.snapshot()};
  }
  job.state="FAILED";return {job,reason:"ACTION_BUDGET_EXHAUSTED",trace:this.trace,graph:this.graph.snapshot()};
 }
}
