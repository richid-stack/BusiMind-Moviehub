import type {Job,Surface} from "./domain.js";
import type {NavigationGateway} from "./engine.js";

export class MockAdaptiveGateway implements NavigationGateway{
 private n=0;
 async observe(job:Job):Promise<Surface[]>{
  return [{botUsername:"@Apple_moviebot",chatId:"c",messageId:"m1",
   text:"The Incredible Hulk (2008)",buttons:[
    {id:"pick",label:"The Incredible Hulk (2008)",kind:"SELECT_MEDIA",row:0,column:0}
   ],observedAt:Date.now()}];
 }
 async click(_job:Job,surface:Surface,buttonId:string){
  this.n++;
  if(buttonId==="pick")return [{botUsername:surface.botUsername,chatId:"c",messageId:"m2",
    replyToMessageId:"m1",text:"The Incredible Hulk (2008) 1080p",
    buttons:[{id:"q",label:"1080p",kind:"SELECT_QUALITY",row:0,column:0}],observedAt:Date.now()}];
  return [];
 }
}
