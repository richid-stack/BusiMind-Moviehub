import type {Surface,Interpretation,Button,SurfaceKind} from "./domain.js";
import {extract,similarity} from "./identity.js";

function buttonKind(b:Button){
 const x=b.label.toLowerCase();
 if(/season|s\d{1,2}/.test(x))return "SELECT_SEASON";
 if(/episode|e\d{1,3}/.test(x))return "SELECT_EPISODE";
 if(/2160|1080|720|480|quality/.test(x))return "SELECT_QUALITY";
 if(/download|get file|file/.test(x))return "DOWNLOAD";
 if(/next|more|page/.test(x))return "NEXT_PAGE";
 if(/prev|back/.test(x))return "PREVIOUS_PAGE";
 return "SELECT_MEDIA";
}

export class EagleEye{
 classifyButtons(surface:Surface):Surface{
  return {...surface,buttons:surface.buttons.map(b=>({...b,kind:b.kind||buttonKind(b)}))};
 }

 interpret(surface:Surface,requestTitle:string):Interpretation{
  const s=this.classifyButtons(surface),x=extract(s.text??"");
  const labels=s.buttons.map(b=>b.label.toLowerCase()).join(" ");
  const hasSeason=s.buttons.some(b=>b.kind==="SELECT_SEASON");
  const hasEpisode=s.buttons.some(b=>b.kind==="SELECT_EPISODE");
  const hasQuality=s.buttons.some(b=>b.kind==="SELECT_QUALITY");
  const hasDownload=s.buttons.some(b=>b.kind==="DOWNLOAD");
  const titleScore=x.title?similarity(x.title,requestTitle):0;
  let kind:SurfaceKind="UNKNOWN",r:string[]=[];
  if(hasDownload||s.media?.length) {kind="DOWNLOAD_SURFACE";r.push("download/media evidence present")}
  else if(hasQuality){kind="QUALITY_SELECTOR";r.push("quality controls observed")}
  else if(hasEpisode){kind="EPISODE_SELECTOR";r.push("episode controls observed")}
  else if(hasSeason){kind="SEASON_SELECTOR";r.push("season controls observed")}
  else if(titleScore>=.72){kind="MEDIA_DETAIL";r.push("title closely matches mission")}
  else if(/no result|not found|nothing found|unavailable/i.test(s.text??"")){kind="NO_RESULT";r.push("negative-result language observed")}
  else if(s.buttons.some(b=>b.kind==="NEXT_PAGE")){kind="PAGINATION";r.push("pagination control observed")}
  else if(/error|try again|failed|timeout/i.test(s.text??"")){kind="ERROR_SURFACE";r.push("error/retry language observed")}
  else r.push("surface does not satisfy a known pattern");

  return {kind,confidence:Math.min(1,(titleScore*.6)+(kind==="UNKNOWN"?0:.4)),title:x.title,year:x.year,season:x.season,episode:x.episode,quality:x.quality,rationale:r};
 }

 actions(surface:Surface,interpretation:Interpretation){
  const out:Action[]=[];
  for(const b of surface.buttons){
   let kind:Action["kind"]="SELECT_MEDIA";
   if(b.kind==="SELECT_SEASON")kind="SELECT_SEASON";
   else if(b.kind==="SELECT_EPISODE")kind="SELECT_EPISODE";
   else if(b.kind==="SELECT_QUALITY")kind="SELECT_QUALITY";
   else if(b.kind==="DOWNLOAD")kind="DOWNLOAD";
   else if(b.kind==="NEXT_PAGE")kind="NEXT_PAGE";
   else if(b.kind==="PREVIOUS_PAGE")kind="PREVIOUS_PAGE";
   const score=(kind==="DOWNLOAD"?1:.5)+(interpretation.kind==="QUALITY_SELECTOR"&&kind==="SELECT_QUALITY"?.35:0);
   out.push({kind,buttonId:b.id,label:b.label,score,rationale:[`surface=${interpretation.kind}`]});
  }
  return out.sort((a,b)=>b.score-a.score);
 }
}
