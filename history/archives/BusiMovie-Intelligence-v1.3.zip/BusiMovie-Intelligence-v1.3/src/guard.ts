import type {Action,Job,Button} from "./domain.js";

export function legal(job:Job,action:Action){
 if(job.request.mediaType==="MOVIE"&&
   ["SELECT_SEASON","SELECT_EPISODE"].includes(action.kind))
   return {ok:false,reason:"MOVIE_CANNOT_NAVIGATE_SERIES"};
 if(job.request.mediaType==="SERIES"&&action.kind==="SELECT_SEASON"&&job.request.season===undefined)
   return {ok:true};
 return {ok:true};
}
export function legalButton(job:Job,b:Button){
 if(job.request.mediaType==="MOVIE"&&/season|episode|s\d|e\d/i.test(b.label))
   return {ok:false,reason:"MOVIE_CANNOT_ENTER_EPISODE_FLOW"};
 return {ok:true};
}
