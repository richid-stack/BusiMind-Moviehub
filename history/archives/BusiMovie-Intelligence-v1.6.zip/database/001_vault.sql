CREATE TABLE IF NOT EXISTS media_assets (
  id BIGSERIAL PRIMARY KEY,
  canonical_id TEXT NOT NULL,
  media_type TEXT NOT NULL CHECK (media_type IN ('MOVIE','SERIES','EPISODE')),
  vault_kind TEXT NOT NULL CHECK (vault_kind IN ('MOVIE_VAULT','SERIES_VAULT')),
  title TEXT NOT NULL,
  release_year INTEGER,
  season_number INTEGER,
  episode_number INTEGER,
  source_chat_id TEXT NOT NULL,
  source_message_id BIGINT NOT NULL,
  source_bot TEXT NOT NULL,
  filename TEXT,
  mime_type TEXT,
  size_bytes BIGINT,
  fingerprint TEXT NOT NULL,
  verification_status TEXT NOT NULL CHECK (verification_status = 'VERIFIED'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (source_chat_id, source_message_id)
);
CREATE INDEX IF NOT EXISTS idx_media_assets_canonical ON media_assets(canonical_id);
CREATE INDEX IF NOT EXISTS idx_media_assets_vault ON media_assets(vault_kind);
CREATE INDEX IF NOT EXISTS idx_media_assets_fingerprint ON media_assets(fingerprint);
