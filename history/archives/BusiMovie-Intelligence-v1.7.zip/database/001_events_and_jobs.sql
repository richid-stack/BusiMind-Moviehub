CREATE TABLE IF NOT EXISTS acquisition_jobs (
  job_id TEXT PRIMARY KEY,
  request_json JSONB NOT NULL,
  state TEXT NOT NULL CHECK (state IN ('QUEUED','RUNNING','RETRY_WAIT','SUCCEEDED','FAILED','CANCELLED')),
  attempt INTEGER NOT NULL DEFAULT 0,
  max_attempts INTEGER NOT NULL DEFAULT 5,
  available_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  lease_owner TEXT,
  lease_until TIMESTAMPTZ,
  last_error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_jobs_claim ON acquisition_jobs(state, available_at, created_at);
CREATE TABLE IF NOT EXISTS acquisition_events (
  event_id BIGSERIAL PRIMARY KEY,
  job_id TEXT NOT NULL REFERENCES acquisition_jobs(job_id) ON DELETE CASCADE,
  event_type TEXT NOT NULL,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_events_job ON acquisition_events(job_id, event_id);
CREATE TABLE IF NOT EXISTS idempotency_keys (
  idempotency_key TEXT PRIMARY KEY,
  job_id TEXT NOT NULL REFERENCES acquisition_jobs(job_id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
