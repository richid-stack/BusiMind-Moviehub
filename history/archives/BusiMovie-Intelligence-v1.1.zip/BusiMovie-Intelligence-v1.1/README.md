# BusiMovie Intelligence V1.1

V1.1 upgrades the clean-room V1 prototype into a durable acquisition engine.

## Core guarantees

- A request has one authoritative `mediaType`: MOVIE or SERIES.
- Movie jobs cannot navigate season/episode controls.
- Series jobs cannot be satisfied by movie results.
- Identity verification is deterministic; heuristics are evidence only.
- Telegram "latest message" is never used as acquisition correlation.
- Acquisition state and events are durable in PostgreSQL.
- Every externally observed surface can be recorded as an Eagle Eye observation.
- Hunter can use multiple bot targets with bounded recovery.
- Duplicate work is prevented with idempotency keys.
- UNKNOWN/AMBIGUOUS is preferred over a false identity.

## V1.1 boundary

The GramJS adapter is a real transport boundary but requires Telegram credentials/session setup and production-specific interaction wiring before it can operate against live bots. The mock adapter is deterministic and is the default for tests/demo.

## Run

```bash
npm install
npm run typecheck
npm test
npm run demo
```

Start dependencies:

```bash
docker compose up -d
```

Apply SQL:

```bash
psql "$DATABASE_URL" -f sql/001_init.sql
```
