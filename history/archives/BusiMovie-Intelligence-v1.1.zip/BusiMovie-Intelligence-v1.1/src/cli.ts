import { MediaRequest } from "./domain.js";
import { MockTelegramGateway } from "./telegram.js";
import { InMemoryJobRepository } from "./repository.js";
import { Hunter } from "./hunter.js";
import { AcquisitionCoordinator } from "./coordinator.js";

async function main() {
  const gateway = new MockTelegramGateway();
  const repo = new InMemoryJobRepository();
  const hunter = new Hunter(gateway,repo);
  const coordinator = new AcquisitionCoordinator(hunter);

  const request = MediaRequest.parse({
    mediaType:"MOVIE",
    title:"The Incredible Hulk",
    year:2008,
    quality:"1080p"
  });

  const result = await coordinator.acquire(request);

  console.log(JSON.stringify({
    result,
    events:repo.events,
    observations:repo.observations,
    graph:hunter.getGraph()
  },null,2));
}

main().catch(err => {
  console.error(err);
  process.exitCode = 1;
});
