import type { InteractionEdge, TelegramButton, TelegramSurface } from "./domain.js";
import { classifyButton } from "./telegram.js";

export class EagleEye {
  private surfaces = new Map<string, TelegramSurface>();
  private edges: InteractionEdge[] = [];

  observe(surface: TelegramSurface) {
    const normalized = {
      ...surface,
      buttons: surface.buttons.map(b => ({
        ...b, kind: b.kind === "UNKNOWN" ? classifyButton(b.label) : b.kind
      }))
    };
    this.surfaces.set(`${surface.botUsername}:${surface.chatId}:${surface.messageId}`, normalized);
    return normalized;
  }

  recordTransition(edge: InteractionEdge) {
    this.edges.push(edge);
  }

  getSurface(bot: string, chat: string, message: string) {
    return this.surfaces.get(`${bot}:${chat}:${message}`);
  }

  actionable(surface: TelegramSurface): TelegramButton[] {
    return surface.buttons.filter(b => b.kind !== "UNKNOWN");
  }

  graph() {
    return {surfaces:[...this.surfaces.values()], edges:[...this.edges]};
  }
}
