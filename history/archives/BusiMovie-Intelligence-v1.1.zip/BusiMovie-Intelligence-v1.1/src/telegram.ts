import type { TelegramButton, TelegramSurface, TelegramMedia } from "./domain.js";

export interface TelegramGateway {
  observe(botUsername: string, correlationKey: string): Promise<TelegramSurface[]>;
  click(botUsername: string, chatId: string, messageId: string, buttonId: string): Promise<TelegramSurface[]>;
  sendMessage(botUsername: string, text: string, correlationKey: string): Promise<TelegramSurface[]>;
  forward(botUsername: string, chatId: string, messageId: string, destination: string): Promise<void>;
}

export function classifyButton(label: string): TelegramButton["kind"] {
  const x = label.toLowerCase();
  if (/season|s\d{1,2}/.test(x)) return "SEASON_SELECT";
  if (/episode|e\d{1,3}/.test(x)) return "EPISODE_SELECT";
  if (/1080|720|2160|quality|480/.test(x)) return "QUALITY_SELECT";
  if (/download|get file|file/.test(x)) return "DOWNLOAD";
  if (/next|more|page/.test(x)) return "PAGINATION_NEXT";
  if (/prev|back/.test(x)) return "PAGINATION_PREVIOUS";
  if (/search|find/.test(x)) return "SEARCH";
  return "MEDIA_CANDIDATE";
}

export function button(id: string, label: string): TelegramButton {
  return {id, label, kind: classifyButton(label)};
}

export class MockTelegramGateway implements TelegramGateway {
  private surfaces = new Map<string, TelegramSurface[]>();

  constructor() {
    this.surfaces.set("@Apple_moviebot", [{
      botUsername:"@Apple_moviebot", chatId:"mock-chat", messageId:"100",
      text:"The Incredible Hulk (2008)",
      buttons:[
        button("hulk2008","The Incredible Hulk (2008)"),
        button("hulk2003","Hulk (2003)")
      ],
      observedAt:Date.now()
    }]);
  }

  async observe(bot: string, _key: string) {
    return (this.surfaces.get(bot) ?? []).map(x => ({...x, buttons:[...x.buttons]}));
  }

  async click(_bot: string, _chat: string, _message: string, _button: string) {
    return [];
  }

  async sendMessage(bot: string, text: string, _key: string) {
    const surfaces = this.surfaces.get(bot) ?? [];
    return surfaces.filter(s => (s.text ?? "").toLowerCase().includes(text.toLowerCase().split(" ")[0]));
  }

  async forward(_bot: string, _chat: string, _message: string, _destination: string) {}
}

/**
 * Live transport boundary.
 * This intentionally does not invent authentication, entity resolution, or
 * message-correlation behavior. Those are deployment concerns.
 */
export class GramJsTelegramGateway implements TelegramGateway {
  async observe(_bot: string, _key: string): Promise<TelegramSurface[]> {
    throw new Error("GramJS session not configured: provide Telegram credentials/session and wire the deployment adapter");
  }
  async click(): Promise<TelegramSurface[]> {
    throw new Error("GramJS session not configured");
  }
  async sendMessage(): Promise<TelegramSurface[]> {
    throw new Error("GramJS session not configured");
  }
  async forward(): Promise<void> {
    throw new Error("GramJS session not configured");
  }
}
