import type { AcquisitionJob, AcquisitionState, TelegramSurface, Evidence } from "./domain.js";

export interface JobRepository {
  create(job: AcquisitionJob): Promise<void>;
  updateState(jobId: string, state: AcquisitionState, failureReason?: string): Promise<void>;
  appendEvent(jobId: string, eventType: string, payload?: unknown, botUsername?: string): Promise<void>;
  recordObservation(jobId: string, surface: TelegramSurface): Promise<void>;
}

export class InMemoryJobRepository implements JobRepository {
  jobs = new Map<string, AcquisitionJob>();
  events: Array<{jobId:string; eventType:string; payload:unknown; botUsername?:string}> = [];
  observations: TelegramSurface[] = [];

  async create(job: AcquisitionJob) { this.jobs.set(job.id, structuredClone(job)); }
  async updateState(jobId: string, state: AcquisitionState, failureReason?: string) {
    const job = this.jobs.get(jobId);
    if (!job) throw new Error("Job not found");
    job.state = state;
    job.failureReason = failureReason as any;
  }
  async appendEvent(jobId: string, eventType: string, payload: unknown = {}, botUsername?: string) {
    this.events.push({jobId,eventType,payload,botUsername});
  }
  async recordObservation(_jobId: string, surface: TelegramSurface) {
    this.observations.push(structuredClone(surface));
  }
}

export interface PersistentDb {
  query(sql: string, params?: unknown[]): Promise<{rows:any[]}>;
}

export class PostgresJobRepository implements JobRepository {
  constructor(private db: PersistentDb) {}

  async create(job: AcquisitionJob) {
    await this.db.query(
      `insert into acquisition_jobs
       (id,idempotency_key,media_type,requested_title,requested_year,season,episode,quality,state)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
      [job.id,job.idempotencyKey,job.request.mediaType,job.request.title,
       job.request.year,job.request.season,job.request.episode,job.request.quality,job.state]
    );
  }

  async updateState(jobId: string, state: AcquisitionState, failureReason?: string) {
    await this.db.query(
      `update acquisition_jobs set state=$2,failure_reason=$3,updated_at=now() where id=$1`,
      [jobId,state,failureReason ?? null]
    );
  }

  async appendEvent(jobId: string, eventType: string, payload: unknown = {}, botUsername?: string) {
    await this.db.query(
      `insert into acquisition_events(job_id,event_type,state,bot_username,payload)
       values($1,$2,(select state from acquisition_jobs where id=$1),$3,$4::jsonb)`,
      [jobId,eventType,botUsername ?? null,JSON.stringify(payload)]
    );
  }

  async recordObservation(jobId: string, surface: TelegramSurface) {
    await this.db.query(
      `insert into telegram_observations
       (job_id,bot_username,chat_id,message_id,reply_to_message_id,text_content,buttons,media)
       values($1,$2,$3,$4,$5,$6,$7::jsonb,$8::jsonb)
       on conflict (bot_username,chat_id,message_id) do nothing`,
      [jobId,surface.botUsername,surface.chatId,surface.messageId,
       surface.replyToMessageId ?? null,surface.text ?? null,
       JSON.stringify(surface.buttons),JSON.stringify(surface.media ?? null)]
    );
  }
}
