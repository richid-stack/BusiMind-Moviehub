import pg from "pg";
import fs from "node:fs/promises";
import path from "node:path";

const { Pool } = pg;

export function createPool(url = process.env.DATABASE_URL) {
  if (!url) throw new Error("DATABASE_URL is required");
  return new Pool({connectionString:url});
}

export async function migrate(pool: pg.Pool, sqlFile = path.resolve("sql/001_init.sql")) {
  const sql = await fs.readFile(sqlFile,"utf8");
  await pool.query(sql);
}
