import type { BotProfile, MediaType } from "./domain.js";

export const DEFAULT_BOTS: BotProfile[] = [
  {username:"@Apple_moviebot", mediaType:"MOVIE", priority:1, reliability:.95, enabled:true},
  {username:"@iPapkornDeltaBot", mediaType:"MOVIE", priority:2, reliability:.80, enabled:true},
  {username:"@iPapkornEzPzBot", mediaType:"MOVIE", priority:3, reliability:.70, enabled:true},
  {username:"@quinsonnbot", mediaType:"SERIES", priority:1, reliability:.85, enabled:true}
];

export function eligibleBots(mediaType: MediaType, bots = DEFAULT_BOTS) {
  return bots.filter(b => b.enabled && b.mediaType === mediaType).sort((a,b) => a.priority - b.priority);
}
