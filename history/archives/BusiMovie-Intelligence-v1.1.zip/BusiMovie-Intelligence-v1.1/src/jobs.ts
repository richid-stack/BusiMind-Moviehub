import type { AcquisitionJob, AcquisitionState, FailureReason } from "./domain.js";

const transitions: Record<AcquisitionState, AcquisitionState[]> = {
  CREATED:["PLANNING","FAILED"],
  PLANNING:["EXPLORING","FAILED"],
  EXPLORING:["CANDIDATE_FOUND","EXPLORING","FAILED"],
  CANDIDATE_FOUND:["VERIFYING","EXPLORING","FAILED"],
  VERIFYING:["FORWARDING","EXPLORING","FAILED","VERIFIED"],
  FORWARDING:["INDEXING","FAILED"],
  INDEXING:["SUCCESS","FAILED"],
  VERIFIED:["FORWARDING","SUCCESS","FAILED"],
  SUCCESS:[],
  FAILED:["PLANNING","EXPLORING"],
};

export class JobStateMachine {
  constructor(public job: AcquisitionJob) {}

  move(next: AcquisitionState, failureReason?: FailureReason) {
    if (!transitions[this.job.state].includes(next)) {
      throw new Error(`Invalid transition ${this.job.state} -> ${next}`);
    }
    this.job.state = next;
    this.job.failureReason = failureReason;
    return this.job;
  }
}

export function createIdempotencyKey(req: AcquisitionJob["request"]): string {
  return [
    req.mediaType, req.title.trim().toLowerCase(), req.year ?? "",
    req.season ?? "", req.episode ?? "", req.quality ?? ""
  ].join("|");
}
