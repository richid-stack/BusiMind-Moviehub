import type { Evidence, TelegramSurface } from "./domain.js";
import { evidenceFromTelegram } from "./identity.js";

export interface CrawlerSink {
  persist(surface: TelegramSurface, evidence: Evidence[]): Promise<void>;
}

export class CrawlerEngine {
  constructor(private sink: CrawlerSink) {}

  async ingest(surface: TelegramSurface) {
    const evidence = surface.text
      ? [evidenceFromTelegram(surface.text, `telegram:${surface.botUsername}:${surface.messageId}`)]
      : [];
    await this.sink.persist(surface, evidence);
    return evidence;
  }
}
