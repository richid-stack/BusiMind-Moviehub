import { z } from "zod";

export const MediaType = z.enum(["MOVIE", "SERIES"]);
export type MediaType = z.infer<typeof MediaType>;

export const AcquisitionState = z.enum([
  "CREATED","PLANNING","EXPLORING","CANDIDATE_FOUND","VERIFYING",
  "FORWARDING","INDEXING","VERIFIED","SUCCESS","FAILED"
]);
export type AcquisitionState = z.infer<typeof AcquisitionState>;

export const FailureReason = z.enum([
  "MEDIA_TYPE_MISMATCH","CANONICAL_ID_MISMATCH","YEAR_MISMATCH",
  "SEASON_MISMATCH","EPISODE_MISMATCH","AMBIGUOUS_METADATA",
  "UNVERIFIED_TELEGRAM_MESSAGE","STALE_MESSAGE","WRONG_VAULT",
  "BOT_TIMEOUT","BOT_NO_RESULT","FORWARD_FAILED","INDEX_FAILED",
  "DUPLICATE_ASSET","NO_ELIGIBLE_BOT"
]);
export type FailureReason = z.infer<typeof FailureReason>;

export const MediaRequest = z.object({
  mediaType: MediaType,
  title: z.string().min(1),
  year: z.number().int().optional(),
  season: z.number().int().positive().optional(),
  episode: z.number().int().positive().optional(),
  quality: z.string().optional()
}).superRefine((v, ctx) => {
  if (v.mediaType === "MOVIE" && (v.season !== undefined || v.episode !== undefined)) {
    ctx.addIssue({code:"custom", message:"Movie requests cannot contain season/episode identity"});
  }
  if (v.mediaType === "SERIES" && v.episode !== undefined && v.season === undefined) {
    ctx.addIssue({code:"custom", message:"Episode requires season"});
  }
});
export type MediaRequest = z.infer<typeof MediaRequest>;

export interface CanonicalIdentity {
  mediaType: MediaType;
  title: string;
  year?: number;
  provider?: string;
  providerId?: string;
  season?: number;
  episode?: number;
}

export interface Evidence {
  title?: string;
  year?: number;
  mediaType?: MediaType;
  season?: number;
  episode?: number;
  quality?: string;
  source: string;
  sourceMessageId?: string;
  observedAt?: number;
}

export interface Candidate {
  identity?: CanonicalIdentity;
  evidence: Evidence[];
  confidence: number;
}

export interface BotProfile {
  username: string;
  mediaType: MediaType;
  priority: number;
  reliability: number;
  enabled: boolean;
  capabilities?: string[];
}

export type ButtonKind =
  | "MEDIA_CANDIDATE" | "SEASON_SELECT" | "EPISODE_SELECT"
  | "QUALITY_SELECT" | "DOWNLOAD" | "PAGINATION_NEXT"
  | "PAGINATION_PREVIOUS" | "SEARCH" | "UNKNOWN";

export interface TelegramButton {
  id: string;
  label: string;
  kind: ButtonKind;
  data?: string;
}

export interface TelegramMedia {
  kind: "document" | "video" | "audio" | "photo" | "unknown";
  fileId?: string;
  fileName?: string;
  mimeType?: string;
}

export interface TelegramSurface {
  botUsername: string;
  chatId: string;
  messageId: string;
  replyToMessageId?: string;
  text?: string;
  buttons: TelegramButton[];
  media?: TelegramMedia[];
  observedAt: number;
}

export interface InteractionEdge {
  fromMessageId: string;
  actionId: string;
  toMessageId?: string;
  timestamp: number;
}

export interface AcquisitionJob {
  id: string;
  idempotencyKey: string;
  request: MediaRequest;
  state: AcquisitionState;
  failureReason?: FailureReason;
}
