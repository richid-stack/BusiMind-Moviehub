import { randomUUID } from "node:crypto";
import type { MediaRequest, AcquisitionJob } from "./domain.js";
import { createIdempotencyKey } from "./jobs.js";
import { Hunter } from "./hunter.js";
import type { TelegramGateway } from "./telegram.js";
import type { JobRepository } from "./repository.js";

export class AcquisitionCoordinator {
  constructor(private hunter: Hunter) {}

  async acquire(request: MediaRequest): Promise<AcquisitionJob> {
    const job: AcquisitionJob = {
      id: randomUUID(),
      idempotencyKey: createIdempotencyKey({request} as any),
      request,
      state: "CREATED"
    };
    return this.hunter.hunt(job);
  }
}
