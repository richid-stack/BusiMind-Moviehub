import type { AcquisitionJob, BotProfile, TelegramButton } from "./domain.js";

export function assertBotAllowed(job: AcquisitionJob, bot: BotProfile) {
  if (job.request.mediaType !== bot.mediaType) {
    throw new Error(`Action blocked: ${job.request.mediaType} job cannot use ${bot.mediaType} bot`);
  }
}

export function assertButtonAllowed(job: AcquisitionJob, button: TelegramButton) {
  if (job.request.mediaType === "MOVIE" &&
      (button.kind === "SEASON_SELECT" || button.kind === "EPISODE_SELECT")) {
    throw new Error("Action blocked: movie mission cannot navigate season/episode controls");
  }
}
