import type { AcquisitionJob, Candidate, CanonicalIdentity, BotProfile, TelegramSurface } from "./domain.js";
import { JobStateMachine } from "./jobs.js";
import { assertBotAllowed, assertButtonAllowed } from "./action-guard.js";
import { eligibleBots } from "./bots.js";
import { verifyCandidate, titleSimilarity } from "./identity.js";
import type { TelegramGateway } from "./telegram.js";
import { EagleEye } from "./eagle-eye.js";
import type { JobRepository } from "./repository.js";

export interface Reasoner {
  chooseSurfaceAction(job: AcquisitionJob, surface: TelegramSurface): string | undefined;
}

export class DeterministicReasoner implements Reasoner {
  chooseSurfaceAction(job: AcquisitionJob, surface: TelegramSurface) {
    const buttons = surface.buttons.filter(b => {
      try { assertButtonAllowed(job,b); return true; } catch { return false; }
    });
    const target = buttons.find(b =>
      titleSimilarity(b.label, job.request.title) >= .72 ||
      b.kind === "DOWNLOAD" ||
      (job.request.mediaType === "SERIES" && b.kind === "SEASON_SELECT")
    );
    return target?.id;
  }
}

function candidateFromSurface(job: AcquisitionJob, surface: TelegramSurface): Candidate | undefined {
  if (!surface.text) return;
  const title = surface.text.split("\n")[0].trim();
  const year = surface.text.match(/\b(19|20)\d{2}\b/)?.[0];
  const ep = surface.text.match(/\bS(\d{1,2})E(\d{1,3})\b/i);

  const identity: CanonicalIdentity = {
    mediaType: job.request.mediaType,
    title,
    year: year ? Number(year) : undefined,
    season: ep ? Number(ep[1]) : undefined,
    episode: ep ? Number(ep[2]) : undefined
  };
  return {
    identity,
    evidence:[{title,year:identity.year,season:identity.season,episode:identity.episode,
      source:`telegram:${surface.botUsername}:${surface.messageId}`,
      sourceMessageId:surface.messageId,observedAt:surface.observedAt}],
    confidence:.90
  };
}

export class Hunter {
  constructor(
    private gateway: TelegramGateway,
    private repo: JobRepository,
    private eye = new EagleEye(),
    private reasoner: Reasoner = new DeterministicReasoner()
  ) {}

  async hunt(job: AcquisitionJob, bots = eligibleBots(job.request.mediaType)) {
    const machine = new JobStateMachine(job);
    await this.repo.create(job);
    await this.repo.appendEvent(job.id,"MISSION_CREATED",{request:job.request});

    machine.move("PLANNING");
    await this.repo.updateState(job.id,job.state);
    await this.repo.appendEvent(job.id,"PLAN_CREATED",{botCount:bots.length});

    if (!bots.length) {
      machine.move("FAILED","NO_ELIGIBLE_BOT");
      await this.repo.updateState(job.id,job.state,job.failureReason);
      return job;
    }

    for (const bot of bots) {
      assertBotAllowed(job,bot);
      machine.move("EXPLORING");
      await this.repo.updateState(job.id,job.state);
      await this.repo.appendEvent(job.id,"BOT_ATTEMPT_STARTED",{bot:bot.username},bot.username);

      const surfaces = await this.gateway.sendMessage(bot.username,job.request.title,job.id);

      for (const raw of surfaces) {
        const surface = this.eye.observe(raw);
        await this.repo.recordObservation(job.id,surface);

        const candidate = candidateFromSurface(job,surface);
        if (!candidate) continue;

        machine.move("CANDIDATE_FOUND");
        await this.repo.updateState(job.id,job.state);
        await this.repo.appendEvent(job.id,"CANDIDATE_FOUND",{candidate},bot.username);

        machine.move("VERIFYING");
        await this.repo.updateState(job.id,job.state);

        const verdict = verifyCandidate(job.request,candidate);
        await this.repo.appendEvent(job.id,"VERIFICATION_RESULT",verdict,bot.username);

        if (verdict.ok) {
          machine.move("VERIFIED");
          await this.repo.updateState(job.id,job.state);
          await this.repo.appendEvent(job.id,"ACQUISITION_VERIFIED",{messageId:surface.messageId},bot.username);
          return job;
        }

        await this.repo.appendEvent(job.id,"CANDIDATE_REJECTED",{reason:verdict.reason},bot.username);
      }

      await this.repo.appendEvent(job.id,"BOT_ATTEMPT_EXHAUSTED",{bot:bot.username},bot.username);
    }

    machine.move("FAILED","BOT_NO_RESULT");
    await this.repo.updateState(job.id,job.state,job.failureReason);
    return job;
  }

  getGraph() { return this.eye.graph(); }
}
