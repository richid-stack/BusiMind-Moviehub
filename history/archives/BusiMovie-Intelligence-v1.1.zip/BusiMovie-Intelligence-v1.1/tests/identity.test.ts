import { describe, expect, it } from "vitest";
import { verifyCandidate, titleSimilarity } from "../src/identity.js";

describe("identity verification", () => {
  it("rejects Hulk 2003 when requesting Incredible Hulk 2008", () => {
    const result = verifyCandidate(
      {mediaType:"MOVIE",title:"The Incredible Hulk",year:2008},
      {identity:{mediaType:"MOVIE",title:"Hulk",year:2003},
       evidence:[],confidence:.99}
    );
    expect(result.ok).toBe(false);
    expect(result.reason).toBe("CANONICAL_ID_MISMATCH");
  });

  it("rejects a series result for a movie request", () => {
    const result = verifyCandidate(
      {mediaType:"MOVIE",title:"The Incredible Hulk",year:2008},
      {identity:{mediaType:"SERIES",title:"The Incredible Hulk",year:2008},
       evidence:[],confidence:.99}
    );
    expect(result.reason).toBe("MEDIA_TYPE_MISMATCH");
  });

  it("rejects wrong episode", () => {
    const result = verifyCandidate(
      {mediaType:"SERIES",title:"Example Show",year:2024,season:1,episode:2},
      {identity:{mediaType:"SERIES",title:"Example Show",year:2024,season:1,episode:1},
       evidence:[],confidence:.99}
    );
    expect(result.reason).toBe("EPISODE_MISMATCH");
  });

  it("uses title similarity only as a gate, not canonical authority", () => {
    expect(titleSimilarity("The Incredible Hulk","The Incredible Hulk")).toBe(1);
    expect(titleSimilarity("Hulk","The Incredible Hulk")).toBeLessThan(.72);
  });
});
