import { describe, expect, it } from "vitest";
import { CrawlerEngine } from "../src/crawler.js";

describe("crawler", () => {
  it("persists structured evidence instead of treating raw text as identity", async () => {
    let got:any;
    const crawler = new CrawlerEngine({
      async persist(surface,evidence){ got={surface,evidence}; }
    });
    await crawler.ingest({
      botUsername:"@Apple_moviebot",
      chatId:"c",
      messageId:"1",
      text:"The Incredible Hulk (2008) 1080p",
      buttons:[],
      observedAt:Date.now()
    });
    expect(got.evidence[0].year).toBe(2008);
    expect(got.evidence[0].quality).toBe("1080p");
  });
});
