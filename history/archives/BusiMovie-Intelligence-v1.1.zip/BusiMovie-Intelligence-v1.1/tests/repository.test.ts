import { describe, expect, it } from "vitest";
import { InMemoryJobRepository } from "../src/repository.js";

describe("durable repository contract", () => {
  it("records ordered events and observations", async () => {
    const repo = new InMemoryJobRepository();
    const job:any = {
      id:"j",idempotencyKey:"k",
      request:{mediaType:"MOVIE",title:"X"},
      state:"CREATED"
    };
    await repo.create(job);
    await repo.appendEvent("j","MISSION_CREATED");
    await repo.recordObservation("j",{
      botUsername:"@x",chatId:"c",messageId:"m",buttons:[],observedAt:1
    });
    expect(repo.events[0].eventType).toBe("MISSION_CREATED");
    expect(repo.observations[0].messageId).toBe("m");
  });
});
