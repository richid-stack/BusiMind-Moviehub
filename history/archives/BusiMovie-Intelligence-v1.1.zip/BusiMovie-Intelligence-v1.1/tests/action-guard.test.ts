import { describe, expect, it } from "vitest";
import { assertButtonAllowed, assertBotAllowed } from "../src/action-guard.js";

const movieJob:any = {request:{mediaType:"MOVIE"}};
const seriesBot:any = {username:"@quinsonnbot",mediaType:"SERIES"};

describe("action guard", () => {
  it("blocks movie -> season", () => {
    expect(() => assertButtonAllowed(movieJob,{id:"1",label:"Season 1",kind:"SEASON_SELECT"}))
      .toThrow();
  });
  it("blocks movie -> series bot", () => {
    expect(() => assertBotAllowed(movieJob,seriesBot)).toThrow();
  });
});
