import { describe, expect, it } from "vitest";
import { MockTelegramGateway } from "../src/telegram.js";
import { InMemoryJobRepository } from "../src/repository.js";
import { Hunter } from "../src/hunter.js";

describe("hunter", () => {
  it("finds the exact 2008 movie and stops on verification", async () => {
    const repo = new InMemoryJobRepository();
    const hunter = new Hunter(new MockTelegramGateway(),repo);
    const job:any = {
      id:"job-1",
      idempotencyKey:"MOVIE|the incredible hulk|2008|||",
      request:{mediaType:"MOVIE",title:"The Incredible Hulk",year:2008},
      state:"CREATED"
    };
    const result = await hunter.hunt(job);
    expect(result.state).toBe("VERIFIED");
    expect(repo.events.some(e => e.eventType === "ACQUISITION_VERIFIED")).toBe(true);
  });

  it("never invents a series navigation action for a movie", async () => {
    const repo = new InMemoryJobRepository();
    const hunter = new Hunter(new MockTelegramGateway(),repo);
    const graph = hunter.getGraph();
    expect(graph.edges).toEqual([]);
  });
});
