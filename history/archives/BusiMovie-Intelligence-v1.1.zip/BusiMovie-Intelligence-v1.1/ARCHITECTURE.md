# V1.1 Architecture

```text
Typed Request
     |
     v
Acquisition Coordinator
     |
     +---- PostgreSQL Job/Event Repository
     |
     +---- Bot Registry / Target Policy
     |
     v
Hunter Mission
     |
     +---- Eagle Eye observation graph
     |
     +---- Telegram Gateway
     |
     +---- Action Guard
     |
     +---- Identity Verification
     |
     v
Verified Candidate
     |
     v
Vault Router / Indexer boundary
```

## Separation of authority

LLM/reasoning may propose a navigation action. Action Guard validates the action against the typed mission. Identity Engine decides whether evidence actually matches the requested media entity.

No filename, caption, button label, or bot response is allowed to create canonical identity by itself.

## Durable state

Each acquisition has:
- one idempotency key
- one current state
- append-only acquisition events
- bot attempts
- candidate observations
- verification outcomes

This makes failures replayable rather than invisible.
