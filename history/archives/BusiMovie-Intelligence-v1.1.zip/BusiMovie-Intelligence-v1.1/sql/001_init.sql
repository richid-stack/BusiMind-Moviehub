create table if not exists media_entities (
  id uuid primary key,
  media_type text not null check (media_type in ('MOVIE','SERIES')),
  canonical_title text not null,
  normalized_title text not null,
  release_year int,
  provider text,
  provider_id text,
  created_at timestamptz not null default now(),
  unique(provider, provider_id)
);

create table if not exists acquisition_jobs (
  id uuid primary key,
  idempotency_key text not null unique,
  media_type text not null check (media_type in ('MOVIE','SERIES')),
  requested_title text not null,
  requested_year int,
  season int,
  episode int,
  quality text,
  state text not null,
  failure_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists acquisition_events (
  id bigserial primary key,
  job_id uuid not null references acquisition_jobs(id) on delete cascade,
  event_type text not null,
  state text,
  bot_username text,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists acquisition_events_job_idx
  on acquisition_events(job_id, id);

create table if not exists bot_profiles (
  username text primary key,
  media_type text not null check (media_type in ('MOVIE','SERIES')),
  priority int not null,
  reliability numeric not null default 0.5,
  enabled boolean not null default true
);

create table if not exists telegram_observations (
  id bigserial primary key,
  job_id uuid references acquisition_jobs(id) on delete set null,
  bot_username text not null,
  chat_id text,
  message_id text,
  reply_to_message_id text,
  text_content text,
  buttons jsonb not null default '[]'::jsonb,
  media jsonb,
  observed_at timestamptz not null default now(),
  unique(bot_username, chat_id, message_id)
);

create table if not exists telegram_assets (
  id uuid primary key,
  job_id uuid references acquisition_jobs(id),
  bot_username text,
  chat_id text,
  message_id text,
  media_type text not null check (media_type in ('MOVIE','SERIES')),
  canonical_key text not null,
  episode_key text,
  release_key text,
  verified boolean not null default false,
  created_at timestamptz not null default now(),
  unique(chat_id, message_id)
);
